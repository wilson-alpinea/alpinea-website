import Image from "next/image";
import {
  InternalGuideHeader,
  FlowTag,
  SectionMarker,
  TableOfContents,
  TerminalCard,
  MapCard,
  MapModal,
  PreviewModal,
  ImageCard,
  CaptionedImage,
  ImmigrationArrivalGuide,
  SubStepHeading,
  StatCard,
  TransportSummaryTable,
  IconBulb,
  IconExchange,
  IconClock,
  IconMap,
  IconTrain,
  IconPlaneLanding,
  IconPlaneTakeoff,
  IconCard,
  IconLuggage,
  IconCar,
  IconCheck,
  IconFork,
  IconDocument,
  IconStar,
  IconWifi,
  RestaurantMini,
  ActionItem,
  FlowDivider,
  ContentCard,
  IconWarning,
} from "./AirportGuideKit";

// Conteúdo completo do guia do Aeroporto de Narita (NRT) — extraído de
// app/database/aeroportos/narita/page.tsx pra ser reutilizado tanto na
// página interna (banco de conteúdo, uso da equipe) quanto embutido
// diretamente no painel do cliente (app/rf3vk8mp), já que a página /database
// não é acessível a clientes. Editar aqui atualiza os dois lugares.
export function NaritaGuideContent({
  displayClassName,
  internal = true,
}: {
  displayClassName: string;
  // false quando embutido no painel do cliente (app/rf3vk8mp) — oculta o
  // link "Banco de conteúdo" e o selo "Uso interno", que só fazem sentido
  // na página interna /database.
  internal?: boolean;
}) {
  return (
    <div className="bg-[#FDFCF9] text-[#24211D]">
      <InternalGuideHeader
        displayClassName={displayClassName}
        eyebrow="Anexo com Informação Detalhada - Aeroportos - Narita (NRT)"
        title="Narita International Airport - 成田国際空港"
        code="NRT"
        heroImage="/images/Narita-hero.png"
        heroAlt="Vista aérea do pátio de aeronaves e terminais do Aeroporto Internacional de Narita"
        subtitle="Aeroporto Internacional de Narita, em Chiba — a cerca de 60 km a leste do centro de Tóquio. Recebe a maior parte dos voos internacionais de longo curso com destino a Tóquio."
        internal={internal}
      />

      <div className="mx-auto grid max-w-5xl gap-4 px-6 pt-8 md:grid-cols-2 md:px-10">
        <a href="#secao-2">
          <FlowTag Icon={IconPlaneLanding} label="Desembarque" subtitle="Chegada e trâmites de entrada" />
        </a>
        <a href="#secao-5">
          <FlowTag Icon={IconPlaneTakeoff} label="Embarque" subtitle="Trâmites de saída e check-in" />
        </a>
      </div>

      <TableOfContents
        items={[
          { Icon: IconMap, number: 1, label: "Visão Geral", href: "#secao-1" },
          {
            Icon: IconPlaneLanding,
            number: 2,
            label: "Chegada e Imigração",
            href: "#secao-2",
            groupLabel: "Desembarque",
          },
          {
            Icon: IconBulb,
            number: 3,
            label: "Recomendações Antes de Sair do Aeroporto",
            href: "#secao-3",
            groupLabel: "Desembarque",
            subsections: [
              { label: "Wi-Fi / eSIM", href: "#secao-3-1" },
              { label: "IC Card (Suica/Pasmo)", href: "#secao-3-2" },
              { label: "Câmbio", href: "#secao-3-3" },
              { label: "Restaurantes", href: "#secao-3-4" },
              { label: "Farmácia", href: "#secao-3-5" },
              { label: "Envio de Bagagem (Takkyubin)", href: "#secao-3-6" },
            ],
          },
          {
            Icon: IconTrain,
            number: 4,
            label: "Deslocamento até Tóquio",
            href: "#deslocamento",
            groupLabel: "Desembarque",
            subsections: [
              { label: "Trem", href: "#deslocamento-trem" },
              { label: "Ônibus", href: "#deslocamento-onibus" },
              { label: "Táxi/Uber", href: "#deslocamento-taxi" },
            ],
          },
          {
            Icon: IconLuggage,
            number: 1,
            label: "Antes de Sair do Hotel",
            href: "#secao-5",
            groupLabel: "Embarque",
          },
          {
            Icon: IconCar,
            number: 2,
            label: "Qual Meio de Transporte Escolher?",
            href: "#secao-6",
            groupLabel: "Embarque",
          },
          {
            Icon: IconCheck,
            number: 3,
            label: "Cheguei no Aeroporto, e Agora?",
            href: "#secao-7",
            groupLabel: "Embarque",
          },
          {
            Icon: IconFork,
            number: 4,
            label: "Estou com Fome",
            href: "#secao-8",
            groupLabel: "Embarque",
          },
          {
            Icon: IconDocument,
            number: 5,
            label: "Checagem de Segurança",
            href: "#secao-9",
            groupLabel: "Embarque",
            subsections: [{ label: "Verificação de Passaporte", href: "#secao-9-passaporte" }],
          },
          {
            Icon: IconStar,
            number: 6,
            label: "Pós-Checagem de Segurança",
            href: "#secao-10",
            groupLabel: "Embarque",
            subsections: [
              { label: "Duty Free", href: "#secao-10-dutyfree" },
              { label: "Lounges", href: "#secao-10-lounges" },
            ],
          },
          {
            Icon: IconPlaneTakeoff,
            number: 7,
            label: "Antes do Embarque",
            href: "#secao-11",
            groupLabel: "Embarque",
          },
        ]}
      />

      {/* Visão geral */}
      <section id="secao-1" className="px-6 py-14 md:px-10 md:py-20">
        <div className="mx-auto max-w-5xl space-y-10">
          <SectionMarker number={1} label="Visão Geral" />
          <h2 className={`${displayClassName} text-2xl font-medium text-[#24211D] md:text-3xl`}>
            Como Funciona o Aeroporto de Narita? São Muitos Terminais?
          </h2>
          <p className="max-w-3xl text-base font-light leading-8 text-[#24211D]/88">
            Confirme sempre o terminal na confirmação do voo — companhias e alocações
            mudam com frequência.
          </p>
          <div className="grid gap-4 md:grid-cols-3">
            <TerminalCard
              nome="Terminal 1"
              tipo="Internacional — Ala Norte e Ala Sul. Voos domésticos da ANA e da Peach em área separada, acessada pelo saguão de chegadas da Ala Sul."
              aliancas={[
                {
                  logo: "/images/star-alliance.png",
                  logoAlt: "Logo da Star Alliance",
                  texto: "Ala Sul: Star Alliance (ANA, United, Lufthansa, Air Canada, Thai, Asiana, Ethiopian Airlines, entre outras).",
                },
                {
                  logo: "/images/SkyTeam-Logo.png",
                  logoAlt: "Logo da SkyTeam",
                  texto: "Ala Norte: SkyTeam (Delta, Korean Air, China Airlines, Vietnam Airlines, Garuda Indonesia, entre outras) e a ZIPAIR Tokyo (4F).",
                },
              ]}
            />
            <TerminalCard
              nome="Terminal 2"
              tipo="Internacional, com voos domésticos da JAL."
              aliancas={[
                {
                  logo: "/images/one-world.webp",
                  logoAlt: "Logo da Oneworld",
                  texto: "Oneworld — JAL, British Airways, Finnair, Cathay Pacific, American Airlines, Qatar Airways, Malaysia Airlines, entre outras.",
                },
                {
                  texto: "Emirates também opera no Terminal 2, mas não é alinhada a nenhuma das 3 alianças.",
                },
              ]}
            />
            <TerminalCard
              nome="Terminal 3"
              tipo="Doméstico e internacional — companhias de baixo custo."
              companhias="Jetstar Japan, Spring Airlines Japan, entre outras companhias de baixo custo."
            />
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <MapCard href="#mapa-geral-narita" label="Mapa Geral — Terminal 1, 2 e 3" />
            <MapCard href="#mapa-terminal1" label="Planta do Terminal 1" />
            <MapCard href="#mapa-terminal2" label="Planta do Terminal 2" />
            <MapCard href="#mapa-terminal3" label="Planta do Terminal 3" />
          </div>

          <div className="rounded-2xl border border-[#173B45]/15 bg-[#173B45]/[0.08] p-6 sm:p-8">
            <p className="mb-5 flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-[#173B45]">
              <IconBulb className="h-3.5 w-3.5" />
              Recomendação Ajisai
            </p>
            <h3 className={`${displayClassName} text-xl font-medium text-[#24211D] md:text-2xl`}>
              Errei o Terminal e Agora?
            </h3>

            <div className="mt-5 space-y-4 text-sm leading-7 text-[#24211D]/88 md:text-base md:leading-8">
              <p>
                Diferente do Aeroporto de Guarulhos, em São Paulo, os três terminais de
                Narita <span className="text-[#24211D]">não são conectados entre si</span>.
                Apenas o Terminal 2 e o Terminal 3 têm ligação terrestre — mesmo assim, o
                trajeto a pé leva cerca de 10–15 minutos.
              </p>
            </div>
            <div className="mt-5">
              <MapCard href="#mapa-passagem-t2-t3" label="Passagem entre o Terminal 2 e o Terminal 3" />
            </div>

            <div className="mt-8 space-y-4 pt-6 text-sm leading-7 text-[#24211D]/88 md:text-base md:leading-8">
              <p>
                Se você precisa se deslocar do Terminal 1 para o Terminal 2 ou 3 (ou
                vice-versa), é necessário usar o <span className="text-[#24211D]">transfer interno</span> —
                essa transferência leva em média 10 minutos.
              </p>
            </div>
            <div className="mt-5 grid gap-4 sm:grid-cols-2">
              <MapCard href="#mapa-shuttle-t1-t2" label="Parada do shuttle T1 → T2 (No. 6)" />
              <MapCard href="#mapa-shuttle-t1-t3" label="Parada do shuttle T1 → T3 (No. 1)" />
            </div>
          </div>
        </div>
      </section>

      <MapModal
        id="mapa-geral-narita"
        label="Mapa Geral — Terminal 1, 2 e 3"
        src="/images/visao-geral-narita-todos-terminais.png"
        alt="Mapa geral do Aeroporto de Narita com Terminal 1, 2 e 3 e estacionamentos"
      />
      <MapModal
        id="mapa-terminal1"
        label="Planta do Terminal 1 — Ala Norte e Ala Sul"
        src="/images/T1-Overview.png"
        alt="Planta do Terminal 1 de Narita, com Ala Norte e Ala Sul"
      />
      <MapModal
        id="mapa-terminal2"
        label="Planta do Terminal 2"
        src="/images/visao-geral-terminal-2.png"
        alt="Planta do Terminal 2 de Narita, com esteiras de bagagem, alfândega e paradas de ônibus"
      />
      <MapModal
        id="mapa-terminal3"
        label="Planta do Terminal 3"
        src="/images/visao-geral-terminal3.png"
        alt="Planta do Terminal 3 de Narita, com esteiras de bagagem, alfândega e paradas de ônibus"
      />
      <MapModal
        id="mapa-passagem-t2-t3"
        label="Passagem no 3º andar entre o Terminal 2 e o Terminal 3"
        src="/images/passagem-terminal-terrestre.png"
        alt="Passagem no terceiro andar entre o Terminal 2 e o Terminal 3 de Narita"
      />
      <MapModal
        id="mapa-shuttle-t1-t2"
        label="Parada do shuttle T1 → T2 (No. 6 Terminal Shuttle Bus Stop)"
        src="/images/T1-Terminal-Shuttle.png"
        alt="No. 6 Terminal Shuttle Bus Stop, com destino ao Terminal 2, no Terminal 1 de Narita"
      />
      <MapModal
        id="mapa-shuttle-t1-t3"
        label="Parada do shuttle T1 → T3 (No. 1 Terminal Shuttle Bus Stop)"
        src="/images/T3-terminal-shuttle.png"
        alt="No. 1 Terminal Shuttle Bus Stop, com destino ao Terminal 3, no Terminal 1 de Narita"
      />
      <MapModal
        id="mapa-narita-tokyo"
        label="Mapa da rota — Narita até o centro de Tóquio"
        src="/images/narita-to-tokyo-map.png"
        alt="Mapa de rota do Aeroporto de Narita até o centro de Tóquio, com distância e tempo estimado"
      />

      <FlowDivider
        Icon={IconPlaneLanding}
        title="Desembarque"
        subtitle="Chegada e trâmites de entrada — do pouso à saída do aeroporto, rumo a Tóquio."
        displayClassName={displayClassName}
      />

      {/* Chegada e imigração */}
      <section id="secao-2" className="border-t border-[#DDD8CF] bg-[#F8FAF9] px-6 py-14 md:px-10 md:py-20">
        <div className="mx-auto max-w-3xl">
          <div className="mb-8">
            <SectionMarker number={2} label="Chegada e Imigração" />
          </div>

          <ImmigrationArrivalGuide displayClassName={displayClassName} />
        </div>
      </section>

      {/* Recomendações antes de sair do aeroporto */}
      <section id="secao-3" className="border-t border-[#DDD8CF] px-6 py-14 md:px-10 md:py-20">
        <div className="mx-auto max-w-3xl">
          <div className="mb-8">
            <SectionMarker number={3} label="Recomendações Antes de Sair do Aeroporto" />
          </div>

          <h2 className={`${displayClassName} mb-8 text-2xl font-medium text-[#24211D] md:text-3xl`}>
            Passei pela Imigração e Estou com Minhas Malas, e Agora?
          </h2>

          <div className="space-y-5">
            <p className="text-base font-light leading-8 text-[#24211D]/88">
              O Aeroporto de Narita fica bem distante de Tóquio — em horários com
              trânsito, pode levar até 2 horas para chegar ao centro da cidade. Por
              isso, existem algumas recomendações gerais.
            </p>

            <div className="space-y-4 pt-2">
              <p id="secao-3-1" className="text-sm font-medium uppercase tracking-[0.15em] text-[#24211D]/88">
                3.1 — Aluguel de Pocket Wi-Fi ou eSIM 5G
              </p>
              <p className="text-base font-light leading-8 text-[#24211D]/88">
                Caso ainda não tenha comprado um eSIM 5G, recomendamos que faça o
                aluguel de um wi-fi móvel ou a compra de um eSIM 5G dentro do
                aeroporto.
              </p>

              <div className="grid gap-4 md:grid-cols-3">
                <div className="rounded-2xl border border-[#DDD8CF] bg-[#F8FAF9] p-5">
                  <p className="text-sm font-medium text-[#24211D]">Terminal 1</p>
                  <p className="mt-2 text-sm leading-6 text-[#24211D]/80">
                    Máquinas de venda de chip e guichês de pocket Wi-Fi no 1F, tanto na
                    Ala Sul quanto na Ala Norte.
                  </p>
                </div>
                <div className="rounded-2xl border border-[#DDD8CF] bg-[#F8FAF9] p-5">
                  <p className="text-sm font-medium text-[#24211D]">Terminal 2</p>
                  <p className="mt-2 text-sm leading-6 text-[#24211D]/80">
                    Guichês de pocket Wi-Fi no lobby de embarque, no 3F. Máquinas de
                    eSIM normalmente no 2F.
                  </p>
                </div>
                <div className="rounded-2xl border border-[#DDD8CF] bg-[#F8FAF9] p-5">
                  <p className="text-sm font-medium text-[#24211D]">Terminal 3</p>
                  <p className="mt-2 text-sm leading-6 text-[#24211D]/80">
                    Guichês de pocket Wi-Fi e máquinas de eSIM no 1F.
                  </p>
                </div>
              </div>

              <div className="rounded-2xl border border-[#173B45]/15 bg-[#173B45]/[0.08] p-6 sm:p-8">
                <p className="mb-4 flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-[#173B45]">
                  <IconBulb className="h-3.5 w-3.5" />
                  Recomendação Alpinea
                </p>
                <p className="text-sm leading-7 text-[#24211D]/88 md:text-base md:leading-8">
                  O método mais conveniente é contratar o eSIM digitalmente em
                  aplicativos como Airalo — nós normalmente usamos a própria Airalo
                  para contratação. A vantagem de usar o pocket wi-fi é que você pode
                  conectar vários aparelhos diferentes nele; a desvantagem é que
                  precisa carregá-lo para qualquer lugar que for.
                </p>
              </div>
            </div>

            <div className="space-y-4 border-t border-[#DDD8CF] pt-6">
              <p id="secao-3-2" className="text-sm font-medium uppercase tracking-[0.15em] text-[#24211D]/88">
                3.2 — Comprar IC Card (JR Suica ou Pasmo)
              </p>
              <p className="text-base font-light leading-8 text-[#24211D]/88">
                No Japão, o valor do ticket de metrô é definido pela distância — ou
                seja, você precisa definir o trajeto e comprar o valor correto a cada
                viagem. Para evitar isso, recomendamos adquirir um IC Card (cartão
                pré-pago). Existem dois operadores em Tóquio, JR Suica e Pasmo — não
                existe diferença prática entre os dois: o Suica é produzido pela JR e
                o Pasmo pela Tokyo Metro, ambas entre as maiores operadoras de trem do
                Japão.
              </p>
              <p className="text-base font-light leading-8 text-[#24211D]/88">
                O IC Card também é utilizado e aceito como forma de pagamento em
                lojas de conveniência, pequenas compras e máquinas de bebida na rua.
              </p>
              <div className="grid gap-6 sm:grid-cols-2">
                <CaptionedImage
                  src="/images/suica-vector.png"
                  alt="Cartão JR Suica, com o mascote pinguim"
                  caption="IC Card JR Suica"
                />
                <CaptionedImage
                  src="/images/pasmo-card.webp"
                  alt="Cartão Pasmo, com ícones de trem e ônibus"
                  caption="IC Card Pasmo"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <ImageCard
                    src="/images/ic-metro.png"
                    alt="Catraca do metrô com área de toque para cartão IC e QR code"
                    fit="cover"
                    aspect="aspect-[3/5]"
                    zoomHref="#foto-ic-metro"
                  />
                  <p className="mt-3 text-center text-sm font-medium text-[#24211D]">Catraca do metrô</p>
                  <p className="text-center text-xs text-[#24211D]/70">Aproxime o cartão na área indicada</p>
                </div>
                <div>
                  <ImageCard
                    src="/images/ic-card-2.png"
                    alt="Sensor circular de IC card sendo usado com um cartão Pasmo"
                    fit="cover"
                    aspect="aspect-[3/5]"
                    zoomHref="#foto-ic-sensor"
                  />
                  <p className="mt-3 text-center text-sm font-medium text-[#24211D]">Sensor de aproximação</p>
                  <p className="text-center text-xs text-[#24211D]/70">Encoste o cartão até o bipe</p>
                </div>
                <div>
                  <ImageCard
                    src="/images/ic-card-vending-machine.png"
                    alt="Máquina de bebidas com leitor de IC card por aproximação"
                    fit="cover"
                    aspect="aspect-[3/5]"
                    zoomHref="#foto-ic-vending"
                  />
                  <p className="mt-3 text-center text-sm font-medium text-[#24211D]">Máquinas de bebida</p>
                  <p className="text-center text-xs text-[#24211D]/70">Também aceitam o IC Card</p>
                </div>
              </div>

              <div className="rounded-2xl border border-[#173B45]/15 bg-[#173B45]/[0.08] p-6 sm:p-8">
                <div className="flex flex-col items-center gap-2 text-center">
                  <span className="flex h-12 w-12 items-center justify-center rounded-full bg-[#173B45]/15 text-[#173B45]">
                    <IconCard className="h-6 w-6" />
                  </span>
                  <p className="text-xs uppercase tracking-[0.25em] text-[#173B45]">
                    Suica/Pasmo no celular
                  </p>
                  <span className="rounded-full bg-[#B96432]/10 px-3 py-1 text-[10px] font-medium uppercase tracking-[0.2em] text-[#B96432]">
                    Opcional
                  </span>
                </div>
                <p className="mt-5 text-center text-sm leading-7 text-[#24211D]/88 md:text-base md:leading-8">
                  O cartão IC pode ser adicionado diretamente na Carteira do iPhone
                  (Apple Wallet) ou no Google Wallet, sem precisar de um cartão
                  físico — o que facilita muito caso haja escassez temporária de
                  chips para os cartões tradicionais.
                </p>
                <div className="mt-5 flex flex-wrap items-center justify-center gap-4">
                  <div className="relative h-9 w-16 overflow-hidden rounded-md bg-white p-1.5">
                    <Image src="/images/apple-pay.png" alt="Logo Apple Pay" fill className="object-contain" />
                  </div>
                  <div className="relative h-9 w-16 overflow-hidden rounded-md bg-white p-1.5">
                    <Image
                      src="/images/google-pay-primary-logo-logo.svg"
                      alt="Logo Google Pay"
                      fill
                      className="object-contain"
                    />
                  </div>
                </div>
                <div className="mt-5 space-y-2 text-center text-sm leading-6">
                  <a
                    href="https://support.apple.com/pt-br/108772"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block text-[#173B45] underline underline-offset-2"
                  >
                    Como adicionar o Suica/Pasmo na Apple Wallet →
                  </a>
                  <a
                    href="https://support.google.com/wallet/thread/269371334/n%C3%A3o-consigo-adicionar-o-suica-cart%C3%A3o-de-transporte-do-jap%C3%A3o-na-carteira?hl=pt"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block text-[#173B45] underline underline-offset-2"
                  >
                    Como adicionar o Suica no Google Wallet →
                  </a>
                </div>
              </div>
            </div>

            <div className="space-y-4 border-t border-[#DDD8CF] pt-6">
              <p id="secao-3-3" className="text-sm font-medium uppercase tracking-[0.15em] text-[#24211D]/88">
                3.3 — Câmbio
              </p>
              <p className="text-base font-light leading-8 text-[#24211D]/88">
                Caso planeje fazer uma refeição no aeroporto ou pedir um Uber,
                recomendamos retirar o valor necessário: uma refeição num restaurante
                de sushi de esteira no aeroporto custa, em média, ¥2.000–3.500 por
                pessoa; um Uber de Narita até Shinjuku custa entre ¥26.300 (tarifa
                fixa) e cerca de ¥36.000 (tarifa dinâmica), dependendo do horário.
              </p>
              <p className="text-base font-light leading-8 text-[#24211D]/88">
                Ao chegar no centro de Tóquio, nossa recomendação é trocar o dinheiro
                numa casa de câmbio como a 銀座エクスチェンジ GINZA EXCHANGE (bairro de
                Ginza), ou em bancos como o Mitsubishi-UFJ, que possuem guichê de
                troca de câmbio.
              </p>
            </div>

            <div className="space-y-8 border-t border-[#DDD8CF] pt-6">
              <p id="secao-3-4" className="text-sm font-medium uppercase tracking-[0.15em] text-[#24211D]/88">
                3.4 — Restaurantes
              </p>

              <div className="rounded-2xl border border-[#DDD8CF] bg-[#F8FAF9] p-5">
                <p className="text-sm font-medium text-[#24211D]">Terminal 1</p>
                <p className="mt-2 text-sm leading-6 text-[#24211D]/80">
                  Kaitensushi Misaki (5F), Ramen Ichikakuya (5F), Tonkatsu Shinjuku
                  Saboten (4F) e Tsukiji Sushiiwa (4F). Para comida ocidental:
                  McDonald&apos;s, Starbucks, Shake Shack e Subway (4F).
                </p>
                <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
                  <ImageCard src="/images/misaki.jpg" alt="Sushi de salmão do Kaitensushi Misaki" label="Kaitensushi Misaki" sublabel="≈ ¥1.500–2.500 por pessoa" fit="cover" zoomHref="#foto-misaki" />
                  <ImageCard src="/images/ramen-ichikakuya.jpg" alt="Tigela de ramen do Ramen Ichikakuya" label="Ramen Ichikakuya" sublabel="≈ ¥1.000–1.300 por pessoa" fit="cover" zoomHref="#foto-ramen-ichikakuya" />
                  <ImageCard src="/images/saboten.jpg" alt="Prato de tonkatsu com curry do Tonkatsu Shinjuku Saboten" label="Tonkatsu Shinjuku Saboten" sublabel="≈ ¥1.300–1.800 por pessoa" fit="cover" zoomHref="#foto-saboten" />
                  <ImageCard src="/images/sushi-iwa.jpg" alt="Prato variado de sushi do Tsukiji Sushiiwa" label="Tsukiji Sushiiwa" sublabel="≈ ¥2.500–3.500 por pessoa" fit="cover" zoomHref="#foto-sushi-iwa" />
                </div>
                <div className="mt-4 flex flex-wrap items-center gap-3">
                  {[
                    { src: "/images/mcdonalds.webp", alt: "Logo McDonald's" },
                    { src: "/images/Starbucks-Logo.wine.png", alt: "Logo Starbucks" },
                    { src: "/images/Shake_Shack_logo.svg.webp", alt: "Logo Shake Shack" },
                    { src: "/images/Subway_2016_logo.svg.webp", alt: "Logo Subway" },
                  ].map((logo) => (
                    <div
                      key={logo.src}
                      className="relative h-9 w-16 overflow-hidden rounded-md bg-white p-1.5"
                    >
                      <Image src={logo.src} alt={logo.alt} fill className="object-contain" />
                    </div>
                  ))}
                </div>
              </div>

              <div className="rounded-2xl border border-[#DDD8CF] bg-[#F8FAF9] p-5">
                <p className="text-sm font-medium text-[#24211D]">Terminal 2</p>
                <p className="mt-2 text-sm leading-6 text-[#24211D]/80">
                  Tokyo Tonkotsu by Ippudo (4F), Sushi Uogashi Nihon-ichi (4F),
                  Sushi-go-round Gansozushi (4F) e Tonkatsu Inaba Wako (4F). Para
                  comida ocidental: Starbucks (4F).
                </p>
                <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
                  <ImageCard src="/images/tokyo-tonkotsu.jpg" alt="Tigela de ramen do Tokyo Tonkotsu by Ippudo" label="Tokyo Tonkotsu by Ippudo" sublabel="≈ ¥1.000–1.500 por pessoa" fit="cover" zoomHref="#foto-tokyo-tonkotsu" />
                  <ImageCard src="/images/sushi-uogashi.jpg" alt="Prato variado de sushi do Sushi Uogashi Nihon-ichi" label="Sushi Uogashi Nihon-ichi" sublabel="≈ ¥2.000–3.000 por pessoa" fit="cover" zoomHref="#foto-sushi-uogashi" />
                  <ImageCard src="/images/gansozushi.jpg" alt="Sushi de salmão do Sushi-go-round Gansozushi" label="Sushi-go-round Gansozushi" sublabel="≈ ¥1.500–2.500 por pessoa" fit="cover" zoomHref="#foto-gansozushi" />
                  <ImageCard src="/images/inaba-wako.jpg" alt="Prato de tonkatsu do Tonkatsu Inaba Wako" label="Tonkatsu Inaba Wako" sublabel="≈ ¥1.300–1.800 por pessoa" fit="cover" zoomHref="#foto-inaba-wako" />
                </div>
                <div className="mt-4 flex flex-wrap items-center gap-3">
                  <div className="relative h-9 w-16 overflow-hidden rounded-md bg-white p-1.5">
                    <Image src="/images/Starbucks-Logo.wine.png" alt="Logo Starbucks" fill className="object-contain" />
                  </div>
                </div>
              </div>

              <div className="rounded-2xl border border-[#DDD8CF] bg-[#F8FAF9] p-5">
                <p className="text-sm font-medium text-[#24211D]">Terminal 3</p>
                <p className="mt-2 text-sm leading-6 text-[#24211D]/80">
                  Tatsu Sushi e Freshness Burger (comida ocidental). O Terminal 3 é
                  bem pequeno em comparação aos demais, porém se o objetivo for
                  comer sushi o Tatsu é na verdade um dos 2 melhores restaurantes
                  de sushi da área externa do aeroporto. Se quiser outros tipos de
                  comida, siga até o Terminal 2 pela passagem terrestre no 3F.
                </p>
                <div className="mt-4 grid grid-cols-2 gap-3">
                  <ImageCard src="/images/tatsu-sushi.jpg" alt="Sushi do Tatsu Sushi" label="Tatsu Sushi" sublabel="≈ ¥2.000–3.000 por pessoa" fit="cover" zoomHref="#foto-tatsu-sushi" />
                  <ImageCard src="/images/freshness.jpg" alt="Hambúrguer e batatas do Freshness Burger" label="Freshness Burger" sublabel="≈ ¥900–1.200 por pessoa" fit="cover" zoomHref="#foto-freshness" />
                </div>
              </div>
            </div>

            <div className="space-y-4 border-t border-[#DDD8CF] pt-6">
              <p id="secao-3-5" className="text-sm font-medium uppercase tracking-[0.15em] text-[#24211D]/88">
                3.5 — Farmácia
              </p>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="rounded-2xl border border-[#DDD8CF] bg-[#F8FAF9] p-5">
                  <p className="text-sm font-medium text-[#24211D]">Terminal 1</p>
                  <p className="mt-2 text-sm leading-6 text-[#24211D]/80">
                    4F — Airport Drug e AP American Pharmacy.
                  </p>
                </div>
                <div className="rounded-2xl border border-[#DDD8CF] bg-[#F8FAF9] p-5">
                  <p className="text-sm font-medium text-[#24211D]">Terminal 2</p>
                  <p className="mt-2 text-sm leading-6 text-[#24211D]/80">
                    4F — Drug Box MediCosme.
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-4 border-t border-[#DDD8CF] pt-6">
              <p id="secao-3-6" className="text-sm font-medium uppercase tracking-[0.15em] text-[#24211D]/88">
                3.6 — Envio de Bagagem (Takkyubin)
              </p>
              <div className="rounded-2xl border border-[#173B45]/15 bg-[#173B45]/[0.08] p-6 sm:p-8">
                <div className="flex flex-col items-center gap-2 text-center">
                  <span className="flex h-12 w-12 items-center justify-center rounded-full bg-[#173B45]/15 text-[#173B45]">
                    <IconLuggage className="h-6 w-6" />
                  </span>
                  <p className="text-xs uppercase tracking-[0.25em] text-[#173B45]">
                    Luggage Delivery (TA-Q-BIN)
                  </p>
                  <span className="rounded-full bg-[#B96432]/10 px-3 py-1 text-[10px] font-medium uppercase tracking-[0.2em] text-[#B96432]">
                    Opcional
                  </span>
                </div>
                <div className="relative mx-auto mt-5 h-12 w-24">
                  <Image src="/images/taqbinlogo.png" alt="Logo TA-Q-BIN, da Yamato Transport" fill className="object-contain" />
                </div>
                <p className="mt-5 text-center text-base font-light leading-8 text-[#24211D]/88">
                  Logo na saída do desembarque existe o balcão de envio de malas
                  (Luggage Delivery / Yamato Transport, o TA-Q-BIN). Para clientes de
                  alto padrão ou famílias com muitas malas, mandar a bagagem direto
                  para o hotel — chegando no mesmo dia ou no dia seguinte — e seguir
                  até o centro apenas com uma mochila é um diferencial gigante de
                  conforto.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <PreviewModal
        id="doc-qr-code"
        eyebrow="Documento"
        label="QR Code de exemplo — Visit Japan Web"
        src="/images/qr-code.png"
        alt="Tela do Visit Japan Web mostrando o QR Code de exemplo para imigração e declaração aduaneira"
      />
      <PreviewModal
        id="foto-kiosk-imigracao"
        eyebrow="Imigração"
        label="Quiosque de leitura do QR Code"
        src="/images/kiosk-imigracao-qr-code.jpg"
        alt="Quiosque de leitura do QR Code do Visit Japan Web para imigração e alfândega"
      />
      <PreviewModal
        id="foto-arrivals-placa"
        eyebrow="Imigração"
        label="Placa de Arrivals (到着)"
        src="/images/visao-nova-placa-arrivals.png"
        alt="Placa de sinalização do aeroporto indicando Arrivals (到着), em japonês, inglês, coreano e chinês"
      />
      <PreviewModal
        id="doc-disembarkation"
        eyebrow="Documento"
        label="Disembarkation Card for Foreigner"
        src="/images/disembarkation-card.png"
        alt="Formulário Disembarkation Card for Foreigner — Cartão de Imigração para Não-Residente"
      />
      <PreviewModal
        id="doc-customs"
        eyebrow="Documento"
        label="Customs Declaration"
        src="/images/custom-declaration.png"
        alt="Formulário Customs Declaration — Declaração Aduaneira"
      />

      <PreviewModal
        id="foto-misaki"
        eyebrow="Terminal 1"
        label="Kaitensushi Misaki"
        src="/images/misaki.jpg"
        alt="Sushi de salmão do Kaitensushi Misaki"
      />
      <PreviewModal
        id="foto-ramen-ichikakuya"
        eyebrow="Terminal 1"
        label="Ramen Ichikakuya"
        src="/images/ramen-ichikakuya.jpg"
        alt="Tigela de ramen do Ramen Ichikakuya"
      />
      <PreviewModal
        id="foto-saboten"
        eyebrow="Terminal 1"
        label="Tonkatsu Shinjuku Saboten"
        src="/images/saboten.jpg"
        alt="Prato de tonkatsu com curry do Tonkatsu Shinjuku Saboten"
      />
      <PreviewModal
        id="foto-sushi-iwa"
        eyebrow="Terminal 1"
        label="Tsukiji Sushiiwa"
        src="/images/sushi-iwa.jpg"
        alt="Prato variado de sushi do Tsukiji Sushiiwa"
      />
      <PreviewModal
        id="foto-tokyo-tonkotsu"
        eyebrow="Terminal 2"
        label="Tokyo Tonkotsu by Ippudo"
        src="/images/tokyo-tonkotsu.jpg"
        alt="Tigela de ramen do Tokyo Tonkotsu by Ippudo"
      />
      <PreviewModal
        id="foto-sushi-uogashi"
        eyebrow="Terminal 2"
        label="Sushi Uogashi Nihon-ichi"
        src="/images/sushi-uogashi.jpg"
        alt="Prato variado de sushi do Sushi Uogashi Nihon-ichi"
      />
      <PreviewModal
        id="foto-gansozushi"
        eyebrow="Terminal 2"
        label="Sushi-go-round Gansozushi"
        src="/images/gansozushi.jpg"
        alt="Sushi de salmão do Sushi-go-round Gansozushi"
      />
      <PreviewModal
        id="foto-inaba-wako"
        eyebrow="Terminal 2"
        label="Tonkatsu Inaba Wako"
        src="/images/inaba-wako.jpg"
        alt="Prato de tonkatsu do Tonkatsu Inaba Wako"
      />
      <PreviewModal
        id="foto-tatsu-sushi"
        eyebrow="Terminal 3"
        label="Tatsu Sushi"
        src="/images/tatsu-sushi.jpg"
        alt="Sushi do Tatsu Sushi"
      />
      <PreviewModal
        id="foto-freshness"
        eyebrow="Terminal 3"
        label="Freshness Burger"
        src="/images/freshness.jpg"
        alt="Hambúrguer e batatas do Freshness Burger"
      />

      <PreviewModal
        id="foto-ic-metro"
        eyebrow="IC Card"
        label="Catraca do metrô"
        src="/images/ic-metro.png"
        alt="Catraca do metrô com área de toque para cartão IC e QR code"
      />
      <PreviewModal
        id="foto-ic-sensor"
        eyebrow="IC Card"
        label="Sensor de aproximação"
        src="/images/ic-card-2.png"
        alt="Sensor circular de IC card sendo usado com um cartão Pasmo"
      />
      <PreviewModal
        id="foto-ic-vending"
        eyebrow="IC Card"
        label="Máquinas de bebida"
        src="/images/ic-card-vending-machine.png"
        alt="Máquina de bebidas com leitor de IC card por aproximação"
      />
      <PreviewModal
        id="foto-narita-balcao-limousine"
        eyebrow="Limousine Bus"
        label="Bus Ticket Counter"
        src="/images/narita-limousine-bus-balcao-terminal.webp"
        alt="Balcão de venda de bilhetes do Airport Limousine Bus, com atendentes no saguão do terminal"
      />
      <PreviewModal
        id="foto-narita-ponto-limousine"
        eyebrow="Limousine Bus"
        label="Ponto de Embarque"
        src="/images/narita-limousine-bus-ponto-embarque.webp"
        alt="Ponto de embarque do Airport Limousine Bus, com funcionários organizando as bagagens dos passageiros"
      />

      {/* Deslocamento */}
      <section id="deslocamento" className="border-t border-[#DDD8CF] px-6 py-14 md:px-10 md:py-20">
        <div className="mx-auto max-w-3xl">
          <div className="mb-8">
            <SectionMarker number={4} label="Deslocamento até Tóquio" />
          </div>

          <h2 className={`${displayClassName} mb-8 text-2xl font-medium text-[#24211D] md:text-3xl`}>
            Já Terminei os Preparativos, Como Chego ao Hotel e Qual Meio de Transporte
            Devo Escolher?
          </h2>

          <p className="mb-10 text-base font-light leading-8 text-[#24211D]/88">
            Existem basicamente 3 formas de chegar até Tóquio a partir de Narita.
          </p>

          <div className="mb-10">
            <TransportSummaryTable
              rows={[
                { label: "Trem (N'EX ou Skyliner)", tempo: 4, custo: 5, recomendacao: "Pior Opção" },
                { label: "Ônibus (Limousine Bus)", tempo: 3, custo: 4, recomendacao: "Melhor Custo-Benefício" },
                { label: "Táxi/Uber", tempo: 5, custo: 1, recomendacao: "Opção mais Confortável, porém muito caro" },
              ]}
            />
          </div>

          <div className="mb-10">
            <ImageCard
              src="/images/narita-to-tokyo-map.png"
              alt="Mapa de rota do Aeroporto de Narita até o centro de Tóquio, com distância e tempo estimado"
              fit="cover"
              aspect="aspect-[21/9]"
              zoomHref="#mapa-narita-tokyo"
            />
          </div>

          <div id="deslocamento-trem" className="space-y-5">
            <SubStepHeading number={1} title="Trem" />

            <p className="text-sm font-medium uppercase tracking-[0.15em] text-[#24211D]/74">
              Narita Express (N&apos;EX) — para Shinjuku, Shibuya, Tóquio
            </p>
            <div className="grid gap-4 sm:grid-cols-2">
              <StatCard
                Icon={IconExchange}
                label="Custo"
                value="¥3.250"
                detail="Narita Express, classe normal — até a estação de Shinjuku"
              />
              <StatCard Icon={IconClock} label="Tempo de deslocamento" value="≈ 80 minutos" variant="highlight" />
            </div>
            <p className="text-base font-light leading-8 text-[#24211D]/88">
              Mesmo utilizando o trem expresso (N&apos;EX), o trajeto é longo, e após
              chegar em uma das estações que conectam com a linha expressa você ainda
              vai precisar se deslocar até a estação de metrô mais próxima do seu hotel
              e realizar a parte final do trajeto a pé. A maioria das estações de metrô
              no Japão são grandes e possuem muitos lances de escada, o que torna
              carregar malas após 30h de viagem uma tarefa muito cansativa. Além disso,
              é comum ter que fazer o trajeto em pé dentro do vagão do metrô em alguns
              horários, por lotação dos vagões nos horários de pico.
            </p>

            <p className="pt-2 text-sm font-medium uppercase tracking-[0.15em] text-[#24211D]/74">
              Keisei Skyliner — para Ueno, Asakusa, Ginza, Nihonbashi
            </p>
            <div className="grid gap-4 sm:grid-cols-2">
              <StatCard
                Icon={IconExchange}
                label="Custo"
                value="¥2.310"
                detail="Compra antecipada online — até a estação de Ueno"
              />
              <StatCard Icon={IconClock} label="Tempo de deslocamento" value="≈ 41 minutos" variant="highlight" />
            </div>
            <p className="text-base font-light leading-8 text-[#24211D]/88">
              Para clientes que vão se hospedar no lado leste de Tóquio — Ueno,
              Asakusa, Ginza, Nihonbashi — o Keisei Skyliner costuma ser mais rápido
              que o N&apos;EX (cerca de 36 a 41 minutos até Ueno) e muito confortável,
              já que evita o trajeto mais longo até Shinjuku seguido de baldeação.
            </p>

            <p className="text-base font-light leading-8 text-[#24211D]/88">
              Dentre as 3 opções (Trem, Ônibus, Táxi/Uber), o trem é sem dúvida a
              pior de todas para quem vai para o lado oeste de Tóquio — mas pode
              valer a pena via Skyliner se o hotel for no lado leste.
            </p>
          </div>

          <div id="deslocamento-onibus" className="mt-10 space-y-5 border-t border-[#DDD8CF] pt-8">
            <div className="flex flex-wrap items-center gap-3">
              <SubStepHeading number={2} title="Ônibus" />
              <span className="rounded-full bg-[#173B45]/15 px-3 py-1 text-[10px] uppercase tracking-[0.2em] text-[#173B45]">
                Método recomendado
              </span>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <StatCard
                Icon={IconExchange}
                label="Custo"
                value="¥3.600"
                detail="Limousine Bus — até a estação de Shinjuku"
              />
              <StatCard Icon={IconClock} label="Tempo de deslocamento" value="≈ 105 minutos" variant="highlight" />
            </div>
            <p className="text-base font-light leading-8 text-[#24211D]/88">
              Dependendo do hotel, existe um ônibus chamado Limousine Bus que vai desde
              o aeroporto de Narita até a porta do hotel. Nem todos os hotéis são
              cobertos, mas existe sempre um terminal de ônibus ou estação de metrô
              próximo aos hotéis que possuem paradas finais para esses ônibus.
            </p>
            <p className="text-base font-light leading-8 text-[#24211D]/88">
              De todas as 3 opções, é o melhor custo-benefício: você vai sentado e não
              precisa se preocupar com as bagagens, pois elas vão no bagageiro. A única
              desvantagem é quando não existe ônibus direto ao hotel — nesses casos,
              normalmente recomendamos que seja pego um táxi para a parte final do
              trajeto.
            </p>

            <div className="mt-8 space-y-5 border-t border-[#DDD8CF] pt-8">
              <p className="text-sm font-medium uppercase tracking-[0.15em] text-[#24211D]/88">
                Como Comprar o Bilhete do Limousine Bus
              </p>

              <div className="grid gap-4 sm:grid-cols-2">
                <ImageCard
                  src="/images/narita-limousine-bus-balcao-terminal.webp"
                  alt="Balcão de venda de bilhetes do Airport Limousine Bus, com atendentes no saguão do terminal"
                  label="Bus Ticket Counter"
                  sublabel="Balcão de venda dos bilhetes"
                  fit="cover"
                  aspect="aspect-[4/3]"
                  zoomHref="#foto-narita-balcao-limousine"
                />
                <ImageCard
                  src="/images/narita-limousine-bus-ponto-embarque.webp"
                  alt="Ponto de embarque do Airport Limousine Bus, com funcionários organizando as bagagens dos passageiros"
                  label="Ponto de Embarque"
                  sublabel="Funcionários cuidam das bagagens"
                  fit="cover"
                  aspect="aspect-[4/3]"
                  zoomHref="#foto-narita-ponto-limousine"
                />
              </div>

              <div className="space-y-4">
                <div className="rounded-2xl border border-[#DDD8CF] bg-[#F8FAF9] p-5">
                  <div className="flex items-start gap-4">
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-[#173B45]/40 text-xs font-medium text-[#173B45]">
                      1
                    </span>
                    <p className="text-sm leading-6 text-[#24211D]/88 md:text-base">
                      <span className="font-medium text-[#24211D]">Depois de desembarcar</span>, ao
                      passar pela Imigração, retirar as malas e passar pela Alfândega, você sai
                      direto no <span className="text-[#24211D]">Terminal 2, 1º andar (1F),
                      International Arrivals Lobby</span> — sem precisar subir ou descer de andar.
                      Os balcões de ônibus ficam no próprio saguão de desembarque, perto das áreas
                      de chegada internacional A e B. Procure pelas placas{" "}
                      <span className="text-[#24211D]">BUS TICKETS / BUS TICKET COUNTER</span> ou pelo
                      nome <span className="text-[#24211D]">Airport Limousine / Limousine Bus</span>.
                    </p>
                  </div>
                </div>

                <div className="rounded-2xl border border-[#DDD8CF] bg-[#F8FAF9] p-5">
                  <div className="flex items-start gap-4">
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-[#173B45]/40 text-xs font-medium text-[#173B45]">
                      2
                    </span>
                    <p className="text-sm leading-6 text-[#24211D]/88 md:text-base">
                      <span className="font-medium text-[#24211D]">Onde comprar</span>: no Bus Ticket
                      Counter, que funciona atualmente das{" "}
                      <span className="text-[#24211D]">06:30 às 23:00</span> aproximadamente. No
                      balcão, informe ao atendente o destino — pode simplesmente mostrar no celular,
                      por exemplo &quot;Airport Limousine Bus to Tokyo Station, please&quot;, ou o nome do
                      hotel/ponto de desembarque do seu roteiro. O atendente confere os próximos
                      ônibus disponíveis e indica o melhor horário.
                    </p>
                  </div>
                </div>

                <div className="rounded-2xl border border-[#DDD8CF] bg-[#F8FAF9] p-5">
                  <div className="flex items-start gap-4">
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-[#173B45]/40 text-xs font-medium text-[#173B45]">
                      3
                    </span>
                    <p className="text-sm leading-6 text-[#24211D]/88 md:text-base">
                      <span className="font-medium text-[#24211D]">Escolha o horário</span> com
                      alguma folga — os bilhetes saem vinculados a uma saída específica, então
                      considere o tempo de comprar o bilhete, ir até o ponto, entregar as malas e
                      embarcar. A vantagem de comprar só depois da Imigração é não precisar se
                      preocupar caso o voo atrase ou a Imigração demore mais que o previsto.
                    </p>
                  </div>
                </div>

                <div className="rounded-2xl border border-[#DDD8CF] bg-[#F8FAF9] p-5">
                  <div className="flex items-start gap-4">
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-[#173B45]/40 text-xs font-medium text-[#173B45]">
                      4
                    </span>
                    <p className="text-sm leading-6 text-[#24211D]/88 md:text-base">
                      <span className="font-medium text-[#24211D]">Confira o bilhete</span> antes de
                      sair do balcão: DESTINATION (destino), DEPARTURE TIME (horário de saída) e BUS
                      STOP / PLATFORM (número do ponto) — este último é especialmente importante, já
                      que várias linhas com destinos diferentes saem do Terminal 2.
                    </p>
                  </div>
                </div>

                <div className="rounded-2xl border border-[#DDD8CF] bg-[#F8FAF9] p-5">
                  <div className="flex items-start gap-4">
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-[#173B45]/40 text-xs font-medium text-[#173B45]">
                      5
                    </span>
                    <p className="text-sm leading-6 text-[#24211D]/88 md:text-base">
                      <span className="font-medium text-[#24211D]">Vá para o ponto de ônibus</span>{" "}
                      seguindo as placas BUS / BUS STOPS — as paradas ficam do lado de fora do
                      Terminal 2, ainda no mesmo 1F, sem precisar de elevador, escada ou trem. Saia
                      pela porta indicada e procure o número do ponto impresso no bilhete.
                    </p>
                  </div>
                </div>

                <div className="rounded-2xl border border-[#DDD8CF] bg-[#F8FAF9] p-5">
                  <div className="flex items-start gap-4">
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-[#173B45]/40 text-xs font-medium text-[#173B45]">
                      6
                    </span>
                    <p className="text-sm leading-6 text-[#24211D]/88 md:text-base">
                      <span className="font-medium text-[#24211D]">Entregue as malas</span> ao
                      funcionário no ponto, alguns minutos antes do horário — as malas grandes vão no
                      bagageiro inferior do ônibus, e você recebe um comprovante/etiqueta de bagagem.
                      Guarde essa etiqueta até retirar a mala no destino.
                    </p>
                  </div>
                </div>

                <div className="rounded-2xl border border-[#DDD8CF] bg-[#F8FAF9] p-5">
                  <div className="flex items-start gap-4">
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-[#173B45]/40 text-xs font-medium text-[#173B45]">
                      7
                    </span>
                    <p className="text-sm leading-6 text-[#24211D]/88 md:text-base">
                      <span className="font-medium text-[#24211D]">Embarque</span>: quando o ônibus
                      chegar, confirme no painel frontal/lateral se o destino corresponde ao do seu
                      bilhete, apresente o bilhete ou QR Code e embarque — os assentos são
                      individuais.
                    </p>
                  </div>
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <ContentCard variant="warning" icon={IconWarning} eyebrow="Atenção" size="sm">
                  <p>
                    Não desça para o B1F — é onde ficam as estações dos trens JR e Keisei. Os
                    bilhetes de ônibus são vendidos no 1F, no mesmo andar do desembarque.
                  </p>
                </ContentCard>
                <ContentCard variant="warning" icon={IconWarning} eyebrow="Atenção" size="sm">
                  <p>
                    Não confunda com o balcão identificado como LCB / Low Cost Bus — é um serviço
                    diferente do Airport Limousine Bus.
                  </p>
                </ContentCard>
              </div>
            </div>
          </div>

          <div id="deslocamento-taxi" className="mt-10 space-y-5 border-t border-[#DDD8CF] pt-8">
            <SubStepHeading number={3} title="Táxi/Uber" />
            <div className="grid gap-4 sm:grid-cols-2">
              <StatCard
                Icon={IconExchange}
                label="Custo"
                value="¥26.300 a ¥36.000"
                detail="Táxi (tarifa fixa) a Uber (tarifa dinâmica) — até Shinjuku"
              />
              <StatCard Icon={IconClock} label="Tempo de deslocamento" value="≈ 75 minutos" variant="highlight" />
            </div>
            <p className="text-base font-light leading-8 text-[#24211D]/88">
              É a opção mais cômoda e confortável, mas custa até 10x mais que as
              outras — uma viagem de Narita até Tóquio pode facilmente chegar a
              R$ 1.000,00.
            </p>
            <p className="text-base font-light leading-8 text-[#24211D]/88">
              Recomendo usar somente caso o desembarque em Tóquio ocorra num horário
              muito tarde e já não exista ônibus disponível.
            </p>
          </div>
        </div>
      </section>

      <FlowDivider
        Icon={IconPlaneTakeoff}
        title="Embarque"
        subtitle="Trâmites de saída e check-in — do hotel até a entrada no avião, na volta para casa."
        displayClassName={displayClassName}
      />

      {/* Antes de sair do hotel */}
      <section id="secao-5" className="border-t border-[#DDD8CF] bg-[#F8FAF9] px-6 py-14 md:px-10 md:py-20">
        <div className="mx-auto max-w-3xl">
          <div className="mb-8">
            <SectionMarker number={1} label="Antes de Sair do Hotel" />
          </div>

          <h2 className={`${displayClassName} mb-8 text-2xl font-medium text-[#24211D] md:text-3xl`}>
            O Que Verificar Antes de Sair do Hotel?
          </h2>

          <p className="mb-8 text-base font-light leading-8 text-[#24211D]/88">
            Se programe para sair do hotel pelo menos <span className="text-[#24211D]">3 horas antes</span> do
            horário de embarque.
          </p>

          <div className="grid gap-4 sm:grid-cols-2">
            <ActionItem
              Icon={IconMap}
              title="Confirmar o aeroporto"
              text="Em Tóquio existem dois grandes aeroportos internacionais: Haneda e Narita."
            />
            <ActionItem
              Icon={IconPlaneTakeoff}
              title="Confirmar o Terminal"
              text="Principalmente em Narita, já que não é possível se mover rapidamente entre o Terminal 1 e o Terminal 2/3 — ficam a cerca de 10–15 minutos de distância entre si, após embarcar no transfer."
            />
            <ActionItem
              Icon={IconWifi}
              title="Pocket Wi-Fi"
              text="Conferir se o Pocket Wi-Fi está com você, caso tenha optado por alugar."
            />
            <ActionItem
              Icon={IconDocument}
              title="Passaporte"
              text="Conferir se o passaporte está com você."
            />
          </div>

          <div className="mt-8 rounded-2xl border border-[#173B45]/15 bg-[#173B45]/[0.08] p-6 sm:p-8">
            <p className="mb-5 flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-[#173B45]">
              <IconBulb className="h-3.5 w-3.5" />
              Recomendação Ajisai
            </p>
            <h3 className={`${displayClassName} text-xl font-medium text-[#24211D] md:text-2xl`}>
              Confira o Peso das Malas Antes de Sair
            </h3>
            <p className="mt-5 text-sm leading-7 text-[#24211D]/88 md:text-base md:leading-8">
              Verifique se o peso das malas está de acordo com os limites estabelecidos
              pela companhia aérea. Embora seja difícil ter uma balança no hotel,
              procure distribuir o peso uniformemente entre as malas.
            </p>

            <div className="mt-6 overflow-x-auto rounded-2xl border border-[#DDD8CF]">
              <table className="w-full min-w-[480px] border-collapse text-left text-sm">
                <thead>
                  <tr className="border-b border-[#173B45]/40">
                    <th className="px-5 py-4 text-xs font-medium uppercase tracking-[0.15em] text-[#24211D]">Classe</th>
                    <th className="px-5 py-4 text-xs font-medium uppercase tracking-[0.15em] text-[#24211D]">Peso por mala</th>
                    <th className="px-5 py-4 text-xs font-medium uppercase tracking-[0.15em] text-[#24211D]">Malas incluídas</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="px-5 py-4 font-medium text-[#24211D]">Econômica / Premium Economy</td>
                    <td className="px-5 py-4 text-[#24211D]/88">até 23 kg</td>
                    <td className="px-5 py-4 text-[#24211D]/88">2 malas</td>
                  </tr>
                  <tr className="border-t border-[#DDD8CF]">
                    <td className="px-5 py-4 font-medium text-[#24211D]">Executiva / Primeira Classe</td>
                    <td className="px-5 py-4 text-[#24211D]/88">até 32 kg</td>
                    <td className="px-5 py-4 text-[#24211D]/88">2–3 malas (varia por companhia/rota)</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <p className="mt-6 text-sm leading-7 text-[#24211D]/88 md:text-base md:leading-8">
              Como referência (JAL, rotas internacionais): o excesso entre 23 kg e 32 kg
              costuma gerar uma taxa de aproximadamente <span className="text-[#24211D]">¥10.000 (≈ US$100)</span> por
              mala; entre 32 kg e 45 kg, a taxa sobe para cerca de <span className="text-[#24211D]">¥60.000 (≈
              US$600)</span>. Acima de <span className="text-[#24211D]">45 kg a mala normalmente não é aceita para
              embarque</span> — algumas companhias já recusam qualquer mala acima de 32 kg,
              independentemente do pagamento de taxa, por norma de segurança no
              manuseio. Esses valores variam por companhia aérea e rota — confirme
              sempre a política específica da companhia aérea antes da viagem.
            </p>
          </div>

          <div className="mt-6 rounded-2xl border border-[#173B45]/15 bg-[#173B45]/[0.08] p-6 sm:p-8">
            <p className="mb-4 flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-[#173B45]">
              <IconBulb className="h-3.5 w-3.5" />
              Recomendação Alpinea
            </p>
            <p className="text-sm leading-7 text-[#24211D]/88 md:text-base md:leading-8">
              Se você pretende comprar no duty free, vale a pena pré-reservar online
              antes de sair para o aeroporto — o prazo costuma ir de 1 mês até 2 dias
              antes da viagem, dependendo da loja. Assim, o produto já fica separado
              para retirada na área pós-segurança, sem depender de encontrá-lo em
              estoque no dia do voo.
            </p>
          </div>
        </div>
      </section>

      {/* Qual meio de transporte escolher (embarque) */}
      <section id="secao-6" className="border-t border-[#DDD8CF] px-6 py-14 md:px-10 md:py-20">
        <div className="mx-auto max-w-3xl">
          <div className="mb-8">
            <SectionMarker number={2} label="Qual Meio de Transporte Escolher?" />
          </div>

          <h2 className={`${displayClassName} mb-8 text-2xl font-medium text-[#24211D] md:text-3xl`}>
            Qual Meio de Transporte Escolher Até o Aeroporto?
          </h2>

          <p className="mb-10 text-base font-light leading-8 text-[#24211D]/88">
            Existem basicamente as mesmas 3 formas de ir até Narita que usamos para
            sair de lá (seção &quot;Deslocamento até Tóquio&quot;, no Desembarque) — mas aqui,
            no caminho inverso, a recomendação muda.
          </p>

          <div className="mb-10">
            <TransportSummaryTable
              rows={[
                { label: "Trem (N'EX ou Skyliner)", tempo: 4, custo: 5, recomendacao: "Evitar" },
                { label: "Ônibus (Limousine Bus)", tempo: 3, custo: 4, recomendacao: "Melhor Custo-Benefício" },
                { label: "Táxi/Uber", tempo: 5, custo: 1, recomendacao: "Opção mais Confortável" },
              ]}
            />
          </div>

          <div id="secao-6-trem" className="space-y-5">
            <SubStepHeading number={1} title="Trem" />

            <p className="text-sm font-medium uppercase tracking-[0.15em] text-[#24211D]/74">
              Narita Express (N&apos;EX) — de Shinjuku, Shibuya, Tóquio
            </p>
            <div className="grid gap-4 sm:grid-cols-2">
              <StatCard
                Icon={IconExchange}
                label="Custo"
                value="¥3.250"
                detail="Narita Express, classe normal — a partir da estação de Shinjuku"
              />
              <StatCard Icon={IconClock} label="Tempo de deslocamento" value="≈ 80 minutos" variant="highlight" />
            </div>

            <p className="pt-2 text-sm font-medium uppercase tracking-[0.15em] text-[#24211D]/74">
              Keisei Skyliner — de Ueno, Asakusa, Ginza, Nihonbashi
            </p>
            <div className="grid gap-4 sm:grid-cols-2">
              <StatCard
                Icon={IconExchange}
                label="Custo"
                value="¥2.310"
                detail="Compra antecipada online — a partir da estação de Ueno"
              />
              <StatCard Icon={IconClock} label="Tempo de deslocamento" value="≈ 41 minutos" variant="highlight" />
            </div>

            <p className="text-base font-light leading-8 text-[#24211D]/88">
              Mesmo sendo rápido em trânsito, o trem exige primeiro chegar até a
              estação com as malas, comprar ou validar a passagem, e possivelmente
              enfrentar escadas e catracas ao longo do caminho — tudo isso antes de
              embarcar. Depois de dias de viagem, com bagagem no limite do peso, esse
              trajeto inicial costuma ser mais desgastante do que parece.
            </p>
            <p className="text-base font-light leading-8 text-[#24211D]/88">
              Dentre as 3 opções, o trem é a que menos recomendamos para quem está
              indo embora — o oposto do que acontece no desembarque, quando as malas
              ainda não pesam tanto.
            </p>
          </div>

          <div id="secao-6-onibus" className="mt-10 space-y-5 border-t border-[#DDD8CF] pt-8">
            <div className="flex flex-wrap items-center gap-3">
              <SubStepHeading number={2} title="Ônibus" />
              <span className="rounded-full bg-[#173B45]/15 px-3 py-1 text-[10px] uppercase tracking-[0.2em] text-[#173B45]">
                Método recomendado
              </span>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <StatCard
                Icon={IconExchange}
                label="Custo"
                value="¥3.600"
                detail="Limousine Bus — a partir da estação de Shinjuku"
              />
              <StatCard Icon={IconClock} label="Tempo de deslocamento" value="≈ 105 minutos" variant="highlight" />
            </div>
            <p className="text-base font-light leading-8 text-[#24211D]/88">
              O Limousine Bus passa por diversos hotéis de Tóquio antes de seguir
              direto para Narita — vale confirmar se o hotel do cliente está na rota
              e o horário exato de saída, já que os embarques costumam ser pontuais.
            </p>
            <p className="text-base font-light leading-8 text-[#24211D]/88">
              É a melhor opção para quem está de saída: as malas vão no bagageiro, o
              trajeto é sentado e direto até o terminal, sem baldeações ou escadas no
              meio do caminho.
            </p>
          </div>

          <div id="secao-6-taxi" className="mt-10 space-y-5 border-t border-[#DDD8CF] pt-8">
            <SubStepHeading number={3} title="Táxi/Uber" />
            <div className="grid gap-4 sm:grid-cols-2">
              <StatCard
                Icon={IconExchange}
                label="Custo"
                value="¥26.300 a ¥36.000"
                detail="Táxi (tarifa fixa) a Uber (tarifa dinâmica) — a partir de Shinjuku"
              />
              <StatCard Icon={IconClock} label="Tempo de deslocamento" value="≈ 75 minutos" variant="highlight" />
            </div>
            <p className="text-base font-light leading-8 text-[#24211D]/88">
              Assim como no desembarque, é a opção mais cômoda — porta a porta, sem
              necessidade de arrastar malas em nenhum momento — mas custa até 10x
              mais que as outras.
            </p>
            <p className="text-base font-light leading-8 text-[#24211D]/88">
              Recomendo usar quando o voo for muito cedo pela manhã ou muito tarde à
              noite, fora do horário de funcionamento do Limousine Bus.
            </p>
          </div>
        </div>
      </section>

      {/* Cheguei no aeroporto, e agora? */}
      <section id="secao-7" className="border-t border-[#DDD8CF] bg-[#F8FAF9] px-6 py-14 md:px-10 md:py-20">
        <div className="mx-auto max-w-3xl">
          <div className="mb-8">
            <SectionMarker number={3} label="Cheguei no Aeroporto, e Agora?" />
          </div>

          <h2 className={`${displayClassName} mb-8 text-2xl font-medium text-[#24211D] md:text-3xl`}>
            Cheguei no Aeroporto, e Agora?
          </h2>

          <div className="space-y-5">
            <div className="rounded-2xl border border-[#DDD8CF] bg-[#F8FAF9] p-5">
              <div className="flex items-start gap-4">
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-[#173B45]/40 text-xs font-medium text-[#173B45]">
                  1
                </span>
                <p className="text-sm leading-6 text-[#24211D]/88 md:text-base">
                  <span className="font-medium text-[#24211D]">Devolver o Pocket Wi-Fi</span> no
                  guichê da locadora, no mesmo terminal do embarque.
                </p>
              </div>
              <div className="mt-4 grid gap-3 pl-11 sm:grid-cols-3">
                <div className="rounded-xl border border-[#DDD8CF] bg-[#F8FAF9] p-4">
                  <p className="text-xs font-medium text-[#24211D]">Terminal 1</p>
                  <p className="mt-1.5 text-xs leading-5 text-[#24211D]/78">1F, Ala Sul ou Ala Norte.</p>
                </div>
                <div className="rounded-xl border border-[#DDD8CF] bg-[#F8FAF9] p-4">
                  <p className="text-xs font-medium text-[#24211D]">Terminal 2</p>
                  <p className="mt-1.5 text-xs leading-5 text-[#24211D]/78">Lobby de embarque, 3F.</p>
                </div>
                <div className="rounded-xl border border-[#DDD8CF] bg-[#F8FAF9] p-4">
                  <p className="text-xs font-medium text-[#24211D]">Terminal 3</p>
                  <p className="mt-1.5 text-xs leading-5 text-[#24211D]/78">1F.</p>
                </div>
              </div>
            </div>
            <div className="flex items-start gap-4 rounded-2xl border border-[#DDD8CF] bg-[#F8FAF9] p-5">
              <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-[#173B45]/40 text-xs font-medium text-[#173B45]">
                2
              </span>
              <p className="text-sm leading-6 text-[#24211D]/88 md:text-base">
                <span className="font-medium text-[#24211D]">Confirmar o terminal certo</span> e
                verificar se o check-in/despacho de mala já está disponível —
                normalmente abre cerca de <span className="text-[#24211D]">3 horas antes</span> da partida do
                voo.
              </p>
            </div>
            <div className="flex items-start gap-4 rounded-2xl border border-[#DDD8CF] bg-[#F8FAF9] p-5">
              <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-[#173B45]/40 text-xs font-medium text-[#173B45]">
                3
              </span>
              <p className="text-sm leading-6 text-[#24211D]/88 md:text-base">
                Se dirigir ao guichê e realizar o <span className="text-[#24211D]">check-in</span>.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Estou com fome */}
      <section id="secao-8" className="border-t border-[#DDD8CF] px-6 py-14 md:px-10 md:py-20">
        <div className="mx-auto max-w-3xl">
          <div className="mb-8">
            <SectionMarker number={4} label="Estou com Fome" />
          </div>

          <h2 className={`${displayClassName} mb-8 text-2xl font-medium text-[#24211D] md:text-3xl`}>
            Devo Realizar a Refeição Fora ou Dentro da Área de Segurança?
          </h2>

          <p className="mb-8 text-base font-light leading-8 text-[#24211D]/88">
            Em Narita existem várias opções de comida na parte externa do aeroporto e
            na área após a checagem de segurança. Abaixo, os principais restaurantes
            disponíveis no Terminal 1 e 2{" "}
            <span className="text-[#24211D]">após a checagem de segurança</span>.
          </p>

          <div className="space-y-6">
            <div>
              <p className="mb-4 text-sm font-medium uppercase tracking-[0.15em] text-[#24211D]/88">
                Terminal 1 — Após Segurança
              </p>
              <div className="grid gap-4 sm:grid-cols-2">
                <RestaurantMini
                  name="IPPUDO"
                  detail="Ramen da conhecida rede"
                  location="3F, Central Building"
                />
                <RestaurantMini
                  name="Japanese Grill & Craft Beer TATSU"
                  detail="Grelhados japoneses e cervejas artesanais"
                  location="3F, Central Building"
                />
                <RestaurantMini
                  name="Mitsumoto Tei"
                  detail="Culinária ocidental"
                  location="3F, Central Building"
                />
                <RestaurantMini
                  name="Narita Nakamise"
                  detail="Maior galeria de duty free do Japão, com quiosques de comida rápida japonesa"
                  location="Ala Sul"
                />
              </div>
            </div>

            <div>
              <p className="mb-4 text-sm font-medium uppercase tracking-[0.15em] text-[#24211D]/88">
                Terminal 2 — Após Segurança
              </p>
              <div className="grid gap-4 sm:grid-cols-2">
                <RestaurantMini
                  name="Japan Food Hall"
                  detail="10 restaurantes reunidos — sushi, wagyu à milanesa (katsu), okonomiyaki"
                  location="2F, Main Building"
                />
                <RestaurantMini
                  name="Kyoto Katsugyu"
                  detail="Tonkatsu/gyukatsu estilo Kyoto"
                  location="2F, Main Building"
                />
                <RestaurantMini
                  name="Ginza Kagari"
                  detail="Ramen de assinatura da conhecida casa de Ginza"
                  location="2F, Main Building"
                />
                <RestaurantMini
                  name="T's TanTan"
                  detail="Opção 100% vegana — ramen, gyoza, harumaki"
                  location="2F"
                />
                <RestaurantMini
                  name="Misakimaru"
                  detail="Sushi de boa relação custo-benefício (rede Kyotaru)"
                  location="Terminal 2"
                />
              </div>
            </div>
          </div>

          <p className="mt-8 text-sm leading-6 text-[#24211D]/74">
            Recomendamos confirmar o horário de funcionamento antes — algumas casas
            fecham mais cedo do que o esperado para o último voo do dia.
          </p>
        </div>
      </section>

      {/* Checagem de segurança */}
      <section id="secao-9" className="border-t border-[#DDD8CF] bg-[#F8FAF9] px-6 py-14 md:px-10 md:py-20">
        <div className="mx-auto max-w-3xl">
          <div className="mb-8">
            <SectionMarker number={5} label="Checagem de Segurança e Entrada na Área de Segurança" />
          </div>

          <h2 className={`${displayClassName} mb-8 text-2xl font-medium text-[#24211D] md:text-3xl`}>
            Checagem de Segurança e Entrada na Área de Segurança
          </h2>

          <p className="mb-8 text-base font-light leading-8 text-[#24211D]/88">
            Os procedimentos de segurança em Narita mudam com alguma frequência,
            dependendo da época do ano — mas via de regra:
          </p>

          <div className="rounded-2xl border border-[#DDD8CF] bg-[#F8FAF9] p-6">
            <div className="space-y-1.5 text-sm leading-6 text-[#24211D]/80">
              <p>• É necessário remover o notebook da mala e colocá-lo na bandeja.</p>
              <p>
                • Não é possível embarcar com líquidos acima de 100 ml — se houver
                alguma garrafa maior, é comum pedirem para abrir a mala e verificar.
              </p>
              <p>
                • Exceção: bebidas, cosméticos e outros líquidos comprados no duty
                free após a checagem de segurança podem ser levados sem essa
                restrição.
              </p>
              <p>• Os demais itens proibidos comuns a qualquer aeroporto se aplicam normalmente.</p>
            </div>
          </div>

          <div id="secao-9-passaporte" className="mt-10 space-y-5 border-t border-[#DDD8CF] pt-8">
            <SubStepHeading number={1} title="Verificação de Passaporte" />
            <p className="text-base font-light leading-8 text-[#24211D]/88">
              Em alguns casos, nessa etapa o oficial retira do passaporte os
              comprovantes e notas fiscais de compras feitas no Japão. Pode ser pedido
              para conferir se você está portando algum dos itens citados nas notas,
              assegurando que ele está de fato deixando o país — condição para a
              isenção do imposto de consumo de <span className="text-[#24211D]">10%</span> (8%
              para alimentos/bebidas não alcoólicas), que o não-residente não paga.
            </p>

            <div className="rounded-2xl border border-[#173B45]/15 bg-[#173B45]/[0.08] p-6 sm:p-8">
              <p className="mb-4 flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-[#173B45]">
                <IconClock className="h-3.5 w-3.5" />
                Atualização Importante
              </p>
              <p className="text-sm leading-7 text-[#24211D]/88 md:text-base md:leading-8">
                A partir de <span className="text-[#24211D]">1º de novembro de 2026</span>, o Japão
                substitui esse sistema: você passa a pagar o preço cheio (com imposto)
                na loja e só recebe o reembolso do imposto de consumo em
                terminais/guichês dedicados no aeroporto (Narita incluso), antes de
                embarcar, via escaneamento do passaporte. Se sua viagem for depois
                dessa data, reserve um tempo extra (recomenda-se 45–60 minutos a mais)
                para esse processo de reembolso, já que o sistema ainda estará em
                transição.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Pós-checagem de segurança */}
      <section id="secao-10" className="border-t border-[#DDD8CF] px-6 py-14 md:px-10 md:py-20">
        <div className="mx-auto max-w-3xl">
          <div className="mb-8">
            <SectionMarker number={6} label="Pós-Checagem de Segurança" />
          </div>

          <h2 className={`${displayClassName} mb-8 text-2xl font-medium text-[#24211D] md:text-3xl`}>
            Pós-Checagem de Segurança
          </h2>

          <p className="mb-8 text-base font-light leading-8 text-[#24211D]/88">
            Aqui você tem algumas opções sobre o que fazer antes do embarque — entre
            as mais comuns, restaurantes, compras em duty free ou o lounge/sala VIP
            de sua preferência.
          </p>

          <div className="space-y-4">
            <p className="text-sm font-medium uppercase tracking-[0.15em] text-[#24211D]/88">Restaurantes</p>
            <p className="text-base font-light leading-8 text-[#24211D]/88">
              Ver a lista completa na seção &quot;Estou com Fome&quot;, logo acima — os mesmos
              restaurantes de Terminal 1 e 2 seguem disponíveis nesta etapa, já que
              estão todos após a checagem de segurança.
            </p>
          </div>

          <div id="secao-10-dutyfree" className="mt-10 space-y-4 border-t border-[#DDD8CF] pt-8">
            <p className="text-sm font-medium uppercase tracking-[0.15em] text-[#24211D]/88">Duty Free</p>
            <p className="text-base font-light leading-8 text-[#24211D]/88">
              Você pode <span className="text-[#24211D]">comprar diretamente</span> nas lojas de duty
              free já dentro da área de embarque (pós-segurança) e sair com o produto
              na hora. Se já tiver pré-reservado antes de sair do hotel (ver
              recomendação na seção &quot;Antes de Sair do Hotel&quot;), a retirada é feita no{" "}
              <span className="text-[#24211D]">Duty Free Pick Up Counter</span>, também na área
              pós-segurança — apenas pelo próprio comprador, até 1 hora antes do
              embarque; chegando depois disso, a loja pode não conseguir entregar o
              produto a tempo.
            </p>
          </div>

          <div id="secao-10-lounges" className="mt-10 space-y-4 border-t border-[#DDD8CF] pt-8">
            <p className="text-sm font-medium uppercase tracking-[0.15em] text-[#24211D]/88">Lounges</p>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="rounded-2xl border border-[#DDD8CF] bg-[#F8FAF9] p-6">
                <p className="text-sm font-medium text-[#24211D] md:text-base">ANA Lounge — Terminal 1</p>
                <p className="mt-2 text-sm leading-6 text-[#24211D]/80">
                  Inclui opções de ramen e sushi. Aberto a passageiros de Business/First
                  da Star Alliance e elite ANA Mileage Club, ou mediante acesso pago
                  direto pela ANA.{" "}
                  <span className="text-[#24211D]">Não aceita mais Priority Pass</span> —
                  saiu do programa.
                </p>
              </div>
              <div className="rounded-2xl border border-[#DDD8CF] bg-[#F8FAF9] p-6">
                <p className="text-sm font-medium text-[#24211D] md:text-base">JAL Sakura Lounge — Terminal 2</p>
                <p className="mt-2 text-sm leading-6 text-[#24211D]/80">
                  Atende passageiros de Classe Executiva da JAL e parceiras Oneworld
                  (Qatar Airways, British Airways etc.), além de membros JGC/JMB
                  Sapphire ou superior.{" "}
                  <span className="text-[#24211D]">Não aceita Priority Pass</span> — acesso
                  exclusivo por classe/status.
                </p>
              </div>
            </div>

            <p className="pt-2 text-sm leading-7 text-[#24211D]/88 md:text-base md:leading-8">
              Nem o ANA Lounge nem o JAL Sakura Lounge aceitam Priority Pass hoje — se
              o cartão do cliente oferecer acesso via Priority Pass (Nubank
              Ultravioleta, cartões Amex Platinum, entre outros), as salas realmente
              conveniadas ao programa em Narita são estas:
            </p>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="rounded-2xl border border-[#DDD8CF] bg-[#F8FAF9] p-5">
                <p className="text-sm font-medium text-[#24211D]">I.A.S.S Superior Lounge — NOA</p>
                <p className="mt-1.5 text-xs leading-5 text-[#24211D]/78">
                  Terminal 1, 3F, próximo ao portão 26 — pós-segurança.
                </p>
              </div>
              <div className="rounded-2xl border border-[#DDD8CF] bg-[#F8FAF9] p-5">
                <p className="text-sm font-medium text-[#24211D]">I.A.S.S Superior Lounge — KoCoo</p>
                <p className="mt-1.5 text-xs leading-5 text-[#24211D]/78">
                  Terminal 2, 4F, acima da loja Cartier — pós-segurança.
                </p>
              </div>
              <div className="rounded-2xl border border-[#DDD8CF] bg-[#F8FAF9] p-5 sm:col-span-2">
                <p className="text-sm font-medium text-[#24211D]">9h nine hours Narita Airport</p>
                <p className="mt-1.5 text-xs leading-5 text-[#24211D]/78">
                  Terminal 2, subsolo (B1) do estacionamento P2 — landside, antes da
                  segurança. Capsule hotel que aceita Priority Pass para estadia de
                  até 5h, das 9h às 18h.
                </p>
              </div>
            </div>
          </div>

          <div className="mt-8 rounded-2xl border border-[#173B45]/15 bg-[#173B45]/[0.08] p-6 sm:p-8">
            <p className="mb-5 flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-[#173B45]">
              <IconBulb className="h-3.5 w-3.5" />
              Recomendação Ajisai
            </p>
            <p className="text-sm leading-7 text-[#24211D]/88 md:text-base md:leading-8">
              Embora contra-intuitivo, o JAL Sakura Lounge — utilizado pela JAL e
              Qatar Airways, entre outras parceiras, para Business Class — tem
              péssimas opções de refeição. Minha recomendação é fazer a refeição fora
              do lounge se tiver interesse em comer algo melhor; o lounge em si é
              espaçoso e confortável, mas comida realmente não é o forte.
            </p>
            <p className="mt-4 text-sm leading-7 text-[#24211D]/88 md:text-base md:leading-8">
              O melhor lounge de Narita é o ANA Lounge, com opção até de comer ramen e
              sushi.
            </p>
          </div>
        </div>
      </section>

      {/* Antes do embarque */}
      <section id="secao-11" className="border-t border-[#DDD8CF] bg-[#F8FAF9] px-6 py-14 md:px-10 md:py-20">
        <div className="mx-auto max-w-3xl">
          <div className="mb-8">
            <SectionMarker number={7} label="Antes do Embarque" />
          </div>

          <h2 className={`${displayClassName} mb-6 text-2xl font-medium text-[#24211D] md:text-3xl`}>
            Antes do Embarque
          </h2>

          <div className="max-w-xs">
            <StatCard
              Icon={IconClock}
              label="Chegar ao portão"
              value="30 min antes"
              detail="Da abertura do embarque, para evitar qualquer imprevisto"
              variant="highlight"
            />
          </div>
        </div>
      </section>

    </div>
  );
}
