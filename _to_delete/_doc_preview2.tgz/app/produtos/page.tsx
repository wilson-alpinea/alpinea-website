"use client";

import { useEffect, useRef, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Bodoni_Moda } from "next/font/google";
import { PriceCalculator } from "../components/PriceCalculator";
import {
  useCambioUSD,
  brlParaUSDLabel,
  formatBRL,
  formatUSD,
  type Cambio,
} from "../hooks/useCambioUSD";
import { CambioLabel } from "../components/CambioLabel";
import {
  HotelExemplosPropriedades,
  JR_PASS_DIAS_OPCOES,
  COMISSAO_AJISAI_SHOPPING_PCT,
} from "../components/CustomPackageCard";
import { HotelQuoteCalculator } from "../components/HotelQuoteCalculator";
import { ContactCTA } from "../components/ContactCTA";
import { MenuProdutos } from "../components/MenuProdutos";
import {
  TAXA_MAQUINA_CARTAO,
  TAXA_JUROS_CARTAO_MES,
  TAXA_JUROS_PIX_MES,
  calcularSimulacaoCartao,
  calcularParcelasMaxPix,
  calcularSimulacaoPix,
  type FormaPagamentoEscolhida,
} from "../lib/calculadoraCatalogoPublico";

export const display = Bodoni_Moda({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
});

declare global {
  interface Window {
    gtag?: (...args: unknown[]) => void;
  }
}

export const WHATSAPP_NUMBER = "5511930300101";

type ProdutoKey = "roteiro" | "caravana" | "individual" | "personalizado" | "guia";

// Usado na tela de qualificação e para montar a mensagem
// final do WhatsApp — uma única fonte de verdade para nome/preço.
const PRODUTOS: Record<
  ProdutoKey,
  { nome: string; precoBRL: number | null; precoUSD?: number; href: string }
> = {
  roteiro: {
    nome: "Roteiro Personalizado",
    precoBRL: 1500,
    href: "/ajisairoteiros",
  },
  caravana: {
    nome: "Caravana",
    // Preço "a partir de" — menor valor entre os pacotes Sakura de 7 dias
    // (Sakura 2 - Maio 2027), já em dólar fixo (ver /pacotes).
    precoBRL: null,
    precoUSD: 4280,
    href: "/pacotes#pacotes",
  },
  individual: {
    nome: "Individual ou Pequenos Grupos",
    // Preço "a partir de" — menor valor entre os pacotes Sakura de 7 dias
    // (Sakura 2 - Maio 2027), já em dólar fixo (ver /pacotes).
    precoBRL: null,
    precoUSD: 2490,
    href: "/pacotes#individuais",
  },
  personalizado: {
    nome: "Viagem Personalizada",
    precoBRL: null,
    href: "/viagem-personalizada",
  },
  guia: {
    nome: "Guia Turístico Avulso",
    // Diária cotada nativamente em dólar (não é conversão de um valor em
    // reais) — precoUSD tem prioridade sobre precoBRL no cálculo do preço.
    // US$ 350/dia, cobre até 4 pessoas (mesmo valor usado no calculador do
    // Pacote Personalizado — ver DIARIA_GUIA_USD em CustomPackageCard.tsx).
    precoBRL: null,
    precoUSD: 350,
    href: "/produtos/guia-turistico",
  },
};

// Espelha os 4 blocos do roteiro-vídeo descrito: perfil do dia, detalhe da
// atração, hotéis/restaurantes/anexos e o "nós planejamos, você reserva".
const ROTEIRO_DESTAQUES = [
  "Cada dia planejado de acordo com seu perfil: cidade, horário, atração, deslocamento e refeição.",
  "Cada atração com melhor horário, tempo de visita, estação, transporte recomendado e ingressos.",
  "Hotéis, restaurantes, logística e anexos especiais organizados em um único painel.",
  "Nós planejamos. Você reserva e viaja por conta própria.",
];
export default function ProdutosPage() {
  const cambio = useCambioUSD();

  function precoProdutoLabel(produto: (typeof PRODUTOS)[ProdutoKey], comPrefixo: boolean) {
    if (produto.precoUSD != null) {
      const valor = formatUSD(produto.precoUSD);
      return comPrefixo ? `A partir de ${valor}` : valor;
    }
    if (produto.precoBRL == null) return "Sob consulta";
    const valor = brlParaUSDLabel(produto.precoBRL, cambio);
    return comPrefixo ? `A partir de ${valor}` : valor;
  }

  // Linha "ou R$ X" mostrada junto do preço em dólar — null quando o
  // produto não tem preço fixo (ex: Pacote Personalizado, "Sob consulta").
  function precoBRLProdutoLabel(produto: (typeof PRODUTOS)[ProdutoKey]) {
    if (produto.precoUSD != null) {
      if (!cambio) return null;
      return `ou ${formatBRL(produto.precoUSD * cambio.cotacao)}`;
    }
    if (produto.precoBRL == null) return null;
    return `ou ${formatBRL(produto.precoBRL)}`;
  }

  const [qualProduto, setQualProduto] = useState<ProdutoKey | null>(null);
  const [nome, setNome] = useState("");
  const [periodo, setPeriodo] = useState("");
  const [viajantes, setViajantes] = useState("");
  const [passagens, setPassagens] = useState<"sim" | "nao" | "">("");
  const [primeiraViagem, setPrimeiraViagem] = useState<"sim" | "nao" | "">("");
  const [enviado, setEnviado] = useState(false);
  const [roteiroModalOpen, setRoteiroModalOpen] = useState(false);
  const [pacotesModalOpen, setPacotesModalOpen] = useState(false);
  const [viagemModalOpen, setViagemModalOpen] = useState(false);
  const [passagensModalOpen, setPassagensModalOpen] = useState(false);
  const [guiaModalOpen, setGuiaModalOpen] = useState(false);
  const [servicosModalOpen, setServicosModalOpen] = useState(false);
  // Hoteis abre um popup avulso e leve com os exemplos de propriedade por
  // categoria — nao carrega a Viagem Personalizada (iframe) atras dele.
  const [hoteisModalOpen, setHoteisModalOpen] = useState(false);
  // Pedido do Wilson, 16/set/2026: "JR Pass, Cambio e Seguro Viagem
  // retirar do serviços avulsos, devem virar cards principais [...] seguir
  // mesmo template de layout" — mesmo padrão leve do popup de Hotéis (sem
  // iframe), já que são serviços simples, sem página própria. JR Pass saiu
  // desse padrão em 28/set/2026 e ganhou página própria (/produtos/jrpass
  // — ver comentário no card mais abaixo), por isso não tem mais estado de
  // modal aqui. Seguro Viagem seguiu o mesmo caminho em 29/set/2026
  // (/produtos/seguro-viagem).
  // Pedido do Wilson, 16/set/2026: "criar na pagina de calculadora reversa
  // e produtos um card novo de serviço chamado Ajisai Shopping" — mesmo
  // padrão leve do popup de JR Pass/Câmbio/Seguro Viagem (ServicoAvulsoModal).
  const [ajisaiShoppingModalOpen, setAjisaiShoppingModalOpen] = useState(false);

  // Deep link ?abrir=hoteis — pedido do Wilson, 16/set/2026: "em hotel,
  // colocar link para detalhes do serviço para que ele possa ver o que
  // tem em cada categoria em detalhes" (no PDF/Word da proposta, ver
  // EXPLICACOES_ITEM em PacotePdf.tsx). Lido direto de window.location
  // em vez de useSearchParams (next/navigation) pra não exigir um
  // Suspense boundary só por causa desse popup.
  useEffect(() => {
    if (typeof window === "undefined") return;
    const params = new URLSearchParams(window.location.search);
    if (params.get("abrir") === "hoteis") {
      setHoteisModalOpen(true);
    }
    // ?abrir=roteiro e o evento do menu de três barras (MenuProdutos) abrem
    // o popup do Roteiro Personalizado (Wilson, 27/out/2026).
    if (params.get("abrir") === "roteiro") {
      setRoteiroModalOpen(true);
    }
    const abrirPeloMenu = (e: Event) => {
      if ((e as CustomEvent<string>).detail === "roteiro") setRoteiroModalOpen(true);
    };
    window.addEventListener("alpinea:abrir-produto", abrirPeloMenu);
    return () => window.removeEventListener("alpinea:abrir-produto", abrirPeloMenu);
  }, []);

  useEffect(() => {
    if (
      !roteiroModalOpen &&
      !pacotesModalOpen &&
      !viagemModalOpen &&
      !passagensModalOpen &&
      !guiaModalOpen &&
      !servicosModalOpen &&
      !hoteisModalOpen &&
      !ajisaiShoppingModalOpen
    )
      return;

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setRoteiroModalOpen(false);
        setPacotesModalOpen(false);
        setViagemModalOpen(false);
        setPassagensModalOpen(false);
        setGuiaModalOpen(false);
        setServicosModalOpen(false);
        setHoteisModalOpen(false);
        setAjisaiShoppingModalOpen(false);
      }
    };
    window.addEventListener("keydown", handleKeyDown);

    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [
    roteiroModalOpen,
    pacotesModalOpen,
    viagemModalOpen,
    passagensModalOpen,
    guiaModalOpen,
    servicosModalOpen,
    ajisaiShoppingModalOpen,
    hoteisModalOpen,
  ]);

  // Entrada direta (CTA de cada produto) — vai direto para a qualificação,
  // já com o produto marcado.
  function escolherProduto(produto: ProdutoKey) {
    const produtoSelecionado = PRODUTOS[produto];
    const text = encodeURIComponent(
      `Olá! Tenho interesse em ${produtoSelecionado.nome} e gostaria de receber mais informações.`,
    );

    window.gtag?.("event", "whatsapp_click", {
      form_name: "produtos_interesse_direto",
      produto: produtoSelecionado.nome,
    });
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${text}`, "_blank");
  }

  function trocarProduto() {
    setQualProduto(null);
    setEnviado(false);
  }

  function handleQualificar() {
    if (!qualProduto || !nome) return;
    const produto = PRODUTOS[qualProduto];

    const lines = [
      `Olá! Meu nome é ${nome}.`,
      "Conheci as opções no site e tenho interesse em:",
      "",
      produto.nome,
      periodo && `Período: ${periodo}`,
      viajantes && `Viajantes: ${viajantes}`,
      passagens && `Já possui passagens aéreas: ${passagens === "sim" ? "Sim" : "Não"}`,
      primeiraViagem && `Primeira viagem ao Japão: ${primeiraViagem === "sim" ? "Sim" : "Não"}`,
    ].filter((line): line is string => Boolean(line) || line === "");

    const text = encodeURIComponent(lines.join("\n"));

    window.gtag?.("event", "whatsapp_click", { form_name: "produtos_qualificacao" });
    window.gtag?.("event", "generate_lead", {
      form_name: "produtos_qualificacao",
      contact_channel: "whatsapp",
    });
    window.gtag?.("event", "conversion", {
      send_to: "AW-18262525346/fruBCIiVsMMcEKKLoIRE",
      value: 1.0,
      currency: "BRL",
    });

    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${text}`, "_blank");
    setEnviado(true);
  }

  return (
    <main className="min-h-screen overflow-x-hidden bg-white text-black">
      {/* ── HEADER ── */}
      <header className="fixed left-0 right-0 top-0 z-50 border-b border-white/30 bg-white/55 backdrop-blur-2xl backdrop-saturate-150">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-8 py-5 md:px-16">
          <Link href="/">
            <img
              src="/images/AJISAI-LOGO.avif"
              alt="Ajisai"
              className="h-10 w-auto object-contain invert md:h-11"
            />
          </Link>
          {/* Menu com todos os produtos (Wilson, 26/out/2026). */}
          <MenuProdutos />
        </div>
      </header>

      {/* ── HERO — PRODUTOS ── */}
      <section className="relative border-b border-black/10 bg-white">
        {/*
          HERO RESPONSIVO SEM DEFORMAÇÃO
          - Usa a imagem /images/produtos-hero-matsuri.webp (Gion Matsuri, Kyoto)
          - Mantém a proporção nativa 1375 x 1144
          - Nunca amplia além de 1375px
          - Em widescreen, sobra área preta nas laterais
          - Em telas menores, reduz proporcionalmente
          - Sem object-cover, sem vh, sem crop
        */}
        <div className="relative mx-auto w-full max-w-[1375px] overflow-hidden">
          <Image
            src="/images/produtos-hero-matsuri.webp"
            alt="Viajante de yukata entre as lanternas do Gion Matsuri, em Kyoto"
            width={1375}
            height={1144}
            priority
            sizes="(min-width: 1375px) 1375px, 100vw"
            className="block h-auto w-full"
          />

          <div className="pointer-events-none absolute inset-x-0 bottom-0 h-[28%] bg-gradient-to-t from-black via-black/45 to-transparent" />

          <div className="absolute inset-x-0 bottom-0 z-10 flex justify-center px-5 pb-6 sm:px-8 sm:pb-8 md:px-12 md:pb-10">
            <h1
              className={`${display.className} max-w-5xl text-center text-[clamp(1.8rem,5vw,3.6rem)] font-normal leading-[1.08] tracking-[-0.015em] text-white`}
              style={{ textShadow: "0 3px 18px rgba(0,0,0,0.72)" }}
            >
              Como você quer viajar pelo Japão?
            </h1>
          </div>
        </div>

        {/* ── SELETOR DE PRODUTOS ── */}
        <div className="bg-white px-5 py-10 sm:px-6 sm:py-12 md:px-10 md:py-14 lg:px-16">
          <div className="mx-auto max-w-7xl">
            <h2 className={`${display.className} mb-6 text-2xl font-medium text-black md:text-3xl`}>
              Como você quer organizar sua viagem?
            </h2>

            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              <ProductSelectorCard
                href="#roteiro-personalizado"
                onClick={() => setRoteiroModalOpen(true)}
                icon="/images/produtos/roteiro-personalizado.png"
                iconWidth={439}
                iconHeight={504}
                title="Roteiro Personalizado"
                faixa="azul"
                description="Receba um planejamento completo, criado para sua viagem, e faça suas próprias reservas."
                cta="Conhecer o roteiro"
              />
              <ProductSelectorCard
                href="/pacotes"
                onClick={() => setPacotesModalOpen(true)}
                icon="/images/produtos/pacote-de-viagem.png"
                iconWidth={350}
                iconHeight={532}
                title="Pacote de Viagem"
                faixa="azul"
                description="Escolha uma viagem já estruturada e deixe reservas e organização por nossa conta."
                cta="Ver pacotes"
              />
              <ProductSelectorCard
                href="/viagem-personalizada"
                onClick={() => setViagemModalOpen(true)}
                icon="/images/produtos/viagem-personalizada-icone-v2.png"
                iconWidth={1254}
                iconHeight={1254}
                title="Viagem Personalizada"
                faixa="azul"
                description="Criamos e organizamos sua viagem do zero, inteiramente de acordo com você."
                cta="Criar minha viagem"
                featured
              />
            </div>

            <h2 className={`${display.className} mb-6 mt-12 text-2xl font-medium text-black md:mt-16 md:text-3xl`}>
              Complete sua viagem
            </h2>

            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-6">
              {/* Passagens Aéreas virou página própria no template do
                  Transporte Privado — pedido do Wilson, 30/set/2026 (checkout
                  manual, sem Stone). O popup com /passagens deixou de abrir
                  daqui. */}
              <ProductSelectorCard
                href="/produtos/passagens-aereas"
                icon="/images/produtos/passagem-aerea.png"
                iconWidth={449}
                iconHeight={284}
                title="Passagem Aérea"
                description="Emissão de passagens com suporte antes, durante e depois da sua viagem."
                cta="Ver passagens"
                className="lg:col-span-2"
              />
              {/* Hotéis virou página própria no template do Transporte
                  Privado — pedido do Wilson, 30/set/2026 (checkout manual).
                  O popup com o HotelQuoteCalculator deixou de abrir daqui. */}
              <ProductSelectorCard
                href="/produtos/hoteis"
                icon="/images/produtos/hoteis.png"
                iconWidth={435}
                iconHeight={366}
                title="Hotéis"
                description="Curadoria e reserva de hotéis escolhidos pelo perfil e pela logística da sua viagem."
                cta="Ver hotéis"
                className="lg:col-span-2"
              />
              {/* Guia Turístico virou página própria no template do
                  Transporte Privado — pedido do Wilson, 30/set/2026. */}
              <ProductSelectorCard
                href="/produtos/guia-turistico"
                icon="/images/produtos/guia-turistico.png"
                iconWidth={359}
                iconHeight={444}
                title="Guia Turístico"
                description="Acompanhamento particular no Japão para os dias e experiências que você escolher."
                requirement="Requer Roteiro Personalizado"
                cta="Conhecer o serviço"
                className="lg:col-span-2"
              />
              {/* Transporte Privado virou página própria — pedido do Wilson,
                  29/set/2026 (mesmo template de JR Pass/Câmbio/Seguro
                  Viagem, sem pagamento automático). */}
              <ProductSelectorCard
                href="/produtos/transporte-privado"
                icon="/images/produtos/transporte-privado.png"
                iconWidth={1536}
                iconHeight={1024}
                title="Transporte Privado"
                description="Motorista particular à disposição para deslocamentos e passeios de dia inteiro."
                requirement="Inclui Roteiro Personalizado"
                cta="Calcular meu transporte"
                className="lg:col-span-2"
              />
              {/* Transfer Aeroporto separado do Transporte Privado — pedido
                  do Wilson, 30/set/2026 ("motorista particular e transfer
                  hotel-aeroporto/aeroporto-hotel tem que ser serviços
                  diferentes"). Ícone provisório (arte de linha 160px) até
                  existir uma ilustração no padrão dos outros cards. */}
              <ProductSelectorCard
                href="/produtos/transfer-aeroporto"
                icon="/images/icone-transfer-aeroporto.png"
                iconWidth={160}
                iconHeight={160}
                title="Transfer Aeroporto"
                description="Do aeroporto ao hotel e do hotel ao aeroporto, com motorista esperando no desembarque."
                cta="Calcular meu transfer"
                className="lg:col-span-2"
              />
              {/* Serviços adicionais virou página própria no template do
                  Transporte Privado — pedido do Wilson, 30/set/2026. */}
              <ProductSelectorCard
                href="/produtos/servicos-adicionais"
                icon="/images/produtos/servicos-adicionais.png"
                iconWidth={1254}
                iconHeight={1254}
                title="Serviços adicionais"
                description="Reserva de restaurantes e outros detalhes para completar sua viagem."
                cta="Ver serviços"
                className="lg:col-span-2"
              />
              {/* Pedido do Wilson, 16/set/2026: "JR Pass, Cambio e Seguro
                  Viagem retirar do serviços avulsos, devem virar cards
                  principais como esses listados na imagem, seguir mesmo
                  template de layout" — mesmo componente ProductSelectorCard,
                  mesmos preços de referência já usados no motor de preço
                  (JR_PASS_PRECO_USD, DIARIA_SEGURO_VIAGEM,
                  PRECO_CAMBIO_BRASIL, em CustomPackageCard.tsx). */}
              {/* Pedido do Wilson, 28/set/2026: "em vez de um pop-up, JR
                  Pass agora tem uma pagina propria" — saiu do padrão modal
                  (ver comentário antigo mais abaixo) e virou rota própria
                  em app/produtos/jrpass/page.tsx, com botão de voltar pra
                  cá. Card não passa mais onClick — vira link normal. */}
              <ProductSelectorCard
                href="/produtos/jrpass"
                icon="/images/icone-trem-bala-shinkansen.png"
                iconWidth={1536}
                iconHeight={744}
                title="JR Pass"
                description="Passe ferroviário com deslocamentos ilimitados de trem-bala. Vendido em faixas de 7, 14 ou 21 dias."
                cta="Ver JR Pass"
                className="lg:col-span-2"
              />
              {/* col-start-2 removido — pedido do Wilson, 16/set/2026: "na
                  pagina de produtos o card de ajisai shopping esta
                  totalmente desalinhado, ele deve ir pra fileira de cima".
                  O col-start-2 centralizava a fileira quando só havia 2
                  cards (Câmbio + Seguro Viagem); com o Ajisai Shopping como
                  3º card, ele sobrava sozinho numa linha nova. Sem o
                  offset, os 3 cards (Câmbio, Seguro Viagem, Ajisai
                  Shopping) preenchem a fileira inteira, igual às fileiras
                  acima. */}
              {/* Câmbio também virou página própria — pedido do Wilson,
                  29/set/2026: "agora faça o mesmo para cambio na pagina
                  de produtos" + "cambio só tem PIX"
                  (app/produtos/cambio/page.tsx, Pix pela Stone). */}
              <ProductSelectorCard
                href="/produtos/cambio"
                icon="/images/icone-cambio-dinheiro.png"
                iconWidth={258}
                iconHeight={320}
                title="Câmbio"
                description="Compra e venda de ienes com cotação em tempo real, direto pelo site."
                cta="Ver câmbio"
                className="lg:col-span-2"
              />
              {/* Seguro Viagem também virou página própria — pedido do
                  Wilson, 29/set/2026: "vamos trabalhar agora dentro da
                  página de produtos > seguro viagem, iremos dar o mesmo
                  tratamento que demos em JR Pass" (app/produtos/
                  seguro-viagem/page.tsx, com pagamento Stone). */}
              <ProductSelectorCard
                href="/produtos/seguro-viagem"
                icon="/images/icone-seguro-viagem-v2.png"
                iconWidth={1288}
                iconHeight={1157}
                title="Seguro Viagem"
                description="Cobertura médica e assistência durante toda a viagem."
                cta="Ver seguro viagem"
                className="lg:col-span-2"
              />
              {/* Pedido do Wilson, 16/set/2026: "criar na pagina de
                  calculadora reversa e produtos um card novo de serviço
                  chamado Ajisai Shopping, será um serviço de compra
                  durante a viagem no japao" — mesmo template dos cards
                  acima, comissão de 20% sobre o valor das compras (não uma
                  diária/valor fixo). */}
              {/* Ajisai Shopping virou página própria no template do
                  Transporte Privado — pedido do Wilson, 30/set/2026. */}
              <ProductSelectorCard
                href="/produtos/ajisai-shopping"
                icon="/images/icone-servico-ajisai-shopping.png"
                iconWidth={1254}
                iconHeight={1254}
                title="Ajisai Shopping"
                description="Acompanhamento pessoal em compras durante a viagem no Japão, com negociação, tradução e apoio logístico nas lojas."
                cta="Ver Ajisai Shopping"
                className="lg:col-span-2"
              />
              {/* Pedido do Wilson, 26/out/2026: "criar um card na pagina
                  /produtos somente para eSIM, removendo de serviços
                  adicionais" — primeiro passo da automação da compra de
                  eSIM; a rota própria fica em app/produtos/esim. Ícone
                  enviado pelo Wilson (arte preta sobre fundo transparente,
                  mesma convenção de JR Pass/Câmbio/Seguro/Ajisai Shopping). */}
              <ProductSelectorCard
                href="/produtos/esim"
                icon="/images/icone-esim-v2.png"
                iconWidth={803}
                iconHeight={803}
                title="eSIM"
                description="Internet ilimitada no Japão, instalada no seu celular antes do embarque. Compra online com emissão automática."
                cta="Ver eSIM"
                className="lg:col-span-2"
              />
            </div>
          </div>
        </div>
      </section>

      {/* ── ROTEIRO PERSONALIZADO — DEMONSTRAÇÃO ── */}
      {roteiroModalOpen && (
        <div
          className="fixed inset-0 z-[90] flex items-end justify-center bg-black/85 p-0 backdrop-blur-sm md:items-center md:p-6"
          role="dialog"
          aria-modal="true"
          aria-labelledby="roteiro-modal-title"
          onClick={() => setRoteiroModalOpen(false)}
        >
          <section
            id="roteiro-personalizado"
            className="relative max-h-[94vh] w-full max-w-7xl overflow-y-auto rounded-t-3xl border border-black/10 bg-white px-6 py-16 shadow-2xl md:rounded-3xl md:px-16 md:py-20"
            onClick={(event) => event.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setRoteiroModalOpen(false)}
              aria-label="Fechar informações do Roteiro Personalizado"
              className="sticky right-0 top-0 z-20 ml-auto flex h-10 w-10 items-center justify-center rounded-full border border-black/15 bg-white/70 text-2xl leading-none text-black/65 backdrop-blur transition hover:border-black/40 hover:text-black"
            >
              ×
            </button>
        <div className="mx-auto grid max-w-6xl items-center gap-12 md:grid-cols-2">
          <div>
            <p className="text-[10px] uppercase tracking-[0.2em] text-[#1c6ea8]">
              Roteiro Personalizado
            </p>
            <h2
              id="roteiro-modal-title"
              className={`${display.className} mt-3 text-3xl font-medium leading-tight text-black md:text-4xl`}
            >
              Isto não é uma lista de lugares para visitar.
            </h2>
            <p className="mt-5 text-sm font-light leading-6 text-black/60 md:text-base md:leading-7">
              É um painel digital onde cada dia da sua viagem é planejado de
              acordo com o seu perfil — acessível pelo celular, do início ao
              fim da viagem.
            </p>

            <ul className="mt-6 space-y-3">
              {ROTEIRO_DESTAQUES.map((item) => (
                <li
                  key={item}
                  className={`flex items-start gap-2.5 text-sm leading-6 ${
                    item.startsWith("Nós planejamos") ? "font-medium text-[#1c6ea8]" : "text-black/65"
                  }`}
                >
                  <IconCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#1c6ea8]" />
                  {item}
                </li>
              ))}
            </ul>

            <div className="mt-8 flex flex-wrap items-center gap-6">
              <div>
                <p className="text-[10px] uppercase tracking-[0.2em] text-black/40">A partir de</p>
                <p className={`${display.className} text-4xl font-medium text-black`}>
                  {precoProdutoLabel(PRODUTOS.roteiro, false)}
                </p>
                {precoBRLProdutoLabel(PRODUTOS.roteiro) && (
                  <p className="mt-1 text-lg font-semibold leading-none text-[#2f74ab]">
                    {precoBRLProdutoLabel(PRODUTOS.roteiro)}
                  </p>
                )}
                <CambioLabel cambio={cambio} className="mt-1 text-[11px] text-black/40" />
              </div>
              <button
                type="button"
                onClick={() => {
                  setRoteiroModalOpen(false);
                  escolherProduto("roteiro");
                }}
                className="rounded-full px-6 py-3.5 text-center text-[11px] font-semibold uppercase tracking-[0.2em] text-white shadow-[0_10px_30px_rgba(0,0,0,0.35)] transition duration-300 hover:-translate-y-0.5"
                style={{ backgroundColor: "#2f80c9" }}
              >
                Quero meu roteiro personalizado →
              </button>
            </div>
            <div>
              <PriceCalculator />
            </div>
            <Link
              href="/ajisairoteiros"
              className="mt-5 inline-block text-xs uppercase tracking-[0.2em] text-black/40 underline underline-offset-4 transition hover:text-black"
            >
              Ver o roteiro completo →
            </Link>
          </div>

          <div className="flex justify-center">
            <a
              href="/images/mock-roteiro-iphone.png"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Ver painel do roteiro em tamanho maior"
              className="group relative w-[320px] overflow-visible rounded-[36px] shadow-2xl transition duration-500 hover:-translate-y-1 hover:shadow-[0_25px_60px_rgba(110,195,217,0.25)] md:w-[400px]"
            >
              <div className="relative aspect-[1024/1536] w-full">
                <Image
                  src="/images/mock-roteiro-iphone.png"
                  alt="Painel Ajisai — roteiro diário, atrações e logística organizados"
                  fill
                  sizes="400px"
                  className="object-contain transition duration-700 group-hover:scale-[1.015]"
                />
              </div>
            </a>
          </div>
        </div>

        <div className="mx-auto mt-16 max-w-5xl">
          <p className="text-center text-[10px] uppercase tracking-[0.2em] text-black/40">
            Veja funcionando
          </p>
          <h3
            className={`${display.className} mt-2 text-center text-xl font-medium text-black md:text-2xl`}
          >
            Demonstração do Roteiro Personalizado
          </h3>
          <p className="mx-auto mt-3 max-w-xl text-center text-sm font-light leading-6 text-black/55">
            Duas versões — escolha a que preferir: a rápida dura só 1:46, a
            completa mostra o painel com todos os detalhes.
          </p>
          <div className="mx-auto mt-8 w-full">
            <DemoVideo
              src="/videos/roteiro-personalizado-short.mp4"
              poster="/videos/roteiro-personalizado-short-poster.jpg"
              label="Versão Rápida · 1:46"
              descricao="Visão geral direto ao ponto, em menos de 2 minutos."
            />
          </div>

          <div className="mx-auto mt-10 max-w-sm">
            <p className="text-center text-sm uppercase tracking-[0.2em] text-black/50">
              Quer ver mais?
            </p>
            <div className="mt-3">
              <DemoVideo
                src="/videos/roteiro-personalizado-detalhado.mp4"
                poster="/videos/roteiro-personalizado-detalhado-poster.jpg"
                label="Versão Completa · 8:08"
                descricao="Navegação real pelo painel — dia a dia, atrações, deslocamento e logística."
              />
            </div>
          </div>
        </div>
          </section>
        </div>
      )}

      {pacotesModalOpen && (
        <div
          className="fixed inset-0 z-[90] flex items-end justify-center bg-black/85 p-0 backdrop-blur-sm md:items-center md:p-6"
          role="dialog"
          aria-modal="true"
          aria-labelledby="pacotes-modal-title"
          onClick={() => setPacotesModalOpen(false)}
        >
          <div
            className="relative h-[96vh] w-full max-w-[1500px] overflow-hidden rounded-t-3xl border border-black/10 bg-white shadow-2xl md:h-[94vh] md:rounded-3xl"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="absolute inset-x-0 top-0 z-20 flex h-14 items-center justify-between border-b border-black/10 bg-white/90 px-4 backdrop-blur-xl md:px-6">
              <p
                id="pacotes-modal-title"
                className={`${display.className} text-lg font-medium text-black md:text-xl`}
              >
                Pacotes de Viagem
              </p>
              <div className="flex items-center gap-3">
                <Link
                  href="/pacotes"
                  className="hidden text-[10px] font-semibold uppercase tracking-[0.15em] text-[#1c6ea8] transition hover:text-black sm:block"
                >
                  Abrir página completa
                </Link>
                <button
                  type="button"
                  onClick={() => setPacotesModalOpen(false)}
                  aria-label="Fechar Pacotes de Viagem"
                  className="flex h-9 w-9 items-center justify-center rounded-full border border-black/15 text-2xl leading-none text-black/65 transition hover:border-black/40 hover:text-black"
                >
                  ×
                </button>
              </div>
            </div>
            <iframe
              src="/pacotes"
              title="Conteúdo completo de Pacotes de Viagem"
              className="h-full w-full border-0 pt-14"
            />
          </div>
        </div>
      )}

      {viagemModalOpen && (
        <div
          className="fixed inset-0 z-[90] flex items-end justify-center bg-black/85 p-0 backdrop-blur-sm md:items-center md:p-6"
          role="dialog"
          aria-modal="true"
          aria-labelledby="viagem-modal-title"
          onClick={() => setViagemModalOpen(false)}
        >
          <div
            className="relative h-[96vh] w-full max-w-[1500px] overflow-hidden rounded-t-3xl border border-[#6ec3d9]/30 bg-white shadow-[0_0_60px_-20px_rgba(110,195,217,0.45)] md:h-[94vh] md:rounded-3xl"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="absolute inset-x-0 top-0 z-20 flex h-14 items-center justify-between border-b border-black/10 bg-white/90 px-4 backdrop-blur-xl md:px-6">
              <p
                id="viagem-modal-title"
                className={`${display.className} text-lg font-medium text-black md:text-xl`}
              >
                Viagem Personalizada
              </p>
              <div className="flex items-center gap-3">
                <Link
                  href="/viagem-personalizada"
                  className="hidden text-[10px] font-semibold uppercase tracking-[0.15em] text-[#1c6ea8] transition hover:text-black sm:block"
                >
                  Abrir página completa
                </Link>
                <button
                  type="button"
                  onClick={() => setViagemModalOpen(false)}
                  aria-label="Fechar Viagem Personalizada"
                  className="flex h-9 w-9 items-center justify-center rounded-full border border-black/15 text-2xl leading-none text-black/65 transition hover:border-black/40 hover:text-black"
                >
                  ×
                </button>
              </div>
            </div>
            <iframe
              src="/viagem-personalizada"
              title="Configurador completo de Viagem Personalizada"
              className="h-full w-full border-0 pt-14"
            />
          </div>
        </div>
      )}

      {passagensModalOpen && (
        <div
          className="fixed inset-0 z-[90] flex items-end justify-center bg-black/85 p-0 backdrop-blur-sm md:items-center md:p-6"
          role="dialog"
          aria-modal="true"
          aria-labelledby="passagens-modal-title"
          onClick={() => setPassagensModalOpen(false)}
        >
          <div
            className="relative h-[96vh] w-full max-w-[1500px] overflow-hidden rounded-t-3xl border border-black/10 bg-white shadow-2xl md:h-[94vh] md:rounded-3xl"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="absolute inset-x-0 top-0 z-20 flex h-14 items-center justify-between border-b border-black/10 bg-white/90 px-4 backdrop-blur-xl md:px-6">
              <p
                id="passagens-modal-title"
                className={`${display.className} text-lg font-medium text-black md:text-xl`}
              >
                Passagens Aéreas
              </p>
              <div className="flex items-center gap-3">
                <Link
                  href="/passagens"
                  className="hidden text-[10px] font-semibold uppercase tracking-[0.15em] text-[#1c6ea8] transition hover:text-black sm:block"
                >
                  Abrir página completa
                </Link>
                <button
                  type="button"
                  onClick={() => setPassagensModalOpen(false)}
                  aria-label="Fechar Passagens Aéreas"
                  className="flex h-9 w-9 items-center justify-center rounded-full border border-black/15 text-2xl leading-none text-black/65 transition hover:border-black/40 hover:text-black"
                >
                  ×
                </button>
              </div>
            </div>
            <iframe
              src="/passagens"
              title="Diferenciais Ajisai para Passagens Aéreas"
              className="h-full w-full border-0 pt-14"
            />
          </div>
        </div>
      )}

      {guiaModalOpen && (
        <div
          className="fixed inset-0 z-[90] flex items-end justify-center bg-black/85 p-0 backdrop-blur-sm md:items-center md:p-6"
          role="dialog"
          aria-modal="true"
          aria-labelledby="guia-modal-title"
          onClick={() => setGuiaModalOpen(false)}
        >
          <div
            className="relative h-[96vh] w-full max-w-[1500px] overflow-hidden rounded-t-3xl border border-black/10 bg-white shadow-2xl md:h-[94vh] md:rounded-3xl"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="absolute inset-x-0 top-0 z-20 flex h-14 items-center justify-between border-b border-black/10 bg-white/90 px-4 backdrop-blur-xl md:px-6">
              <p
                id="guia-modal-title"
                className={`${display.className} text-lg font-medium text-black md:text-xl`}
              >
                Guia Turístico Avulso
              </p>
              <div className="flex items-center gap-3">
                <Link
                  href="/guia-turistico"
                  className="hidden text-[10px] font-semibold uppercase tracking-[0.15em] text-[#1c6ea8] transition hover:text-black sm:block"
                >
                  Abrir página completa
                </Link>
                <button
                  type="button"
                  onClick={() => setGuiaModalOpen(false)}
                  aria-label="Fechar Guia Turístico Avulso"
                  className="flex h-9 w-9 items-center justify-center rounded-full border border-black/15 text-2xl leading-none text-black/65 transition hover:border-black/40 hover:text-black"
                >
                  ×
                </button>
              </div>
            </div>
            <iframe
              src="/guia-turistico"
              title="Guia Turístico Avulso"
              className="h-full w-full border-0 pt-14"
            />
          </div>
        </div>
      )}

      {servicosModalOpen && (
        <div
          className="fixed inset-0 z-[90] flex items-end justify-center bg-black/85 p-0 backdrop-blur-sm md:items-center md:p-6"
          role="dialog"
          aria-modal="true"
          aria-labelledby="servicos-modal-title"
          onClick={() => setServicosModalOpen(false)}
        >
          <div
            className="relative h-[96vh] w-full max-w-[1500px] overflow-hidden rounded-t-3xl border border-black/10 bg-white shadow-2xl md:h-[94vh] md:rounded-3xl"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="absolute inset-x-0 top-0 z-20 flex h-14 items-center justify-between border-b border-black/10 bg-white/90 px-4 backdrop-blur-xl md:px-6">
              <p
                id="servicos-modal-title"
                className={`${display.className} text-lg font-medium text-black md:text-xl`}
              >
                Serviços Adicionais
              </p>
              <div className="flex items-center gap-3">
                <Link
                  href="/servicos-adicionais"
                  className="hidden text-[10px] font-semibold uppercase tracking-[0.15em] text-[#1c6ea8] transition hover:text-black sm:block"
                >
                  Abrir página completa
                </Link>
                <button
                  type="button"
                  onClick={() => setServicosModalOpen(false)}
                  aria-label="Fechar Serviços Adicionais"
                  className="flex h-9 w-9 items-center justify-center rounded-full border border-black/15 text-2xl leading-none text-black/65 transition hover:border-black/40 hover:text-black"
                >
                  ×
                </button>
              </div>
            </div>
            <iframe
              src="/servicos-adicionais"
              title="Serviços avulsos Ajisai"
              className="h-full w-full border-0 pt-14"
            />
          </div>
        </div>
      )}

      {/* ── QUALIFICAÇÃO → WHATSAPP ── */}
      <section id="recomendador" className="hidden">
        <div className="mx-auto max-w-2xl">
          {enviado ? (
            <div className="flex flex-col items-center gap-4 py-6 text-center">
              <p className="text-xs uppercase tracking-[0.3em] text-black/40">WhatsApp aberto</p>
              <h2 className={`${display.className} text-2xl font-medium text-black`}>Quase lá.</h2>
              <p className="max-w-xs text-sm leading-6 text-black/55">
                Finalize o envio da mensagem na aba do WhatsApp que abrimos
                para você. A equipe Ajisai responde em breve.
              </p>
              <button
                type="button"
                onClick={trocarProduto}
                className="mt-2 rounded-full border border-black/20 px-6 py-2.5 text-xs uppercase tracking-[0.25em] text-black/80 transition hover:border-black/50 hover:text-black"
              >
                Fazer outra solicitação
              </button>
            </div>
          ) : (
            <>
              {qualProduto && (
                <div className="mb-8 rounded-2xl border border-black/10 bg-black/[0.02] p-6 text-center md:p-7">
                  <p className="text-[10px] uppercase tracking-[0.2em] text-black/40">
                    Produto selecionado
                  </p>
                  <p className={`${display.className} mt-1.5 text-xl font-medium text-black`}>
                    {PRODUTOS[qualProduto].nome}
                  </p>
                  <p className="mt-1 text-xs text-black/50">
                    {precoProdutoLabel(PRODUTOS[qualProduto], true)}
                  </p>
                  {precoBRLProdutoLabel(PRODUTOS[qualProduto]) && (
                    <p className="mt-0.5 text-[11px] text-black/40">
                      {precoBRLProdutoLabel(PRODUTOS[qualProduto])}
                    </p>
                  )}
                  <button
                    type="button"
                    onClick={trocarProduto}
                    className="mt-3 text-[11px] uppercase tracking-[0.15em] text-black/40 underline underline-offset-4 transition hover:text-black"
                  >
                    Trocar produto
                  </button>
                </div>
              )}

              <p className="text-center text-[10px] uppercase tracking-[0.2em] text-[#1c6ea8]">
                Fale com a Ajisai
              </p>
              <h2
                className={`${display.className} mt-3 text-center text-3xl font-medium leading-tight text-black`}
              >
                Conte um pouco sobre sua viagem
              </h2>
              <p className="mt-3 text-center text-sm leading-6 text-black/55">
                Três perguntas rápidas — assim nossa equipe já entra na
                conversa sabendo exatamente o que você precisa.
              </p>

              <div className="mt-8 grid gap-3 sm:grid-cols-2">
                <input
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                  placeholder="Seu nome"
                  className="w-full rounded-lg border border-black/15 bg-black/5 px-3 py-2.5 text-sm text-black outline-none placeholder:text-black/30 focus:border-black/40 sm:col-span-2"
                />
                <input
                  value={periodo}
                  onChange={(e) => setPeriodo(e.target.value)}
                  placeholder="Quando pretende viajar?"
                  className="w-full rounded-lg border border-black/15 bg-black/5 px-3 py-2.5 text-sm text-black outline-none placeholder:text-black/30 focus:border-black/40"
                />
                <input
                  value={viajantes}
                  onChange={(e) => setViajantes(e.target.value)}
                  placeholder="Quantas pessoas viajarão?"
                  className="w-full rounded-lg border border-black/15 bg-black/5 px-3 py-2.5 text-sm text-black outline-none placeholder:text-black/30 focus:border-black/40"
                />
              </div>

              <div className="mt-5">
                <p className="mb-2.5 text-[10px] uppercase tracking-[0.2em] text-black/40">
                  Já possui passagens aéreas?
                </p>
                <div className="flex gap-2.5">
                  {(["sim", "nao"] as const).map((valor) => (
                    <button
                      key={valor}
                      type="button"
                      onClick={() => setPassagens(valor)}
                      className={`rounded-full border px-6 py-2 text-[11px] font-medium uppercase tracking-[0.1em] transition ${
                        passagens === valor
                          ? "border-transparent text-white"
                          : "border-black/20 text-black/60 hover:border-black/50 hover:text-black"
                      }`}
                      style={passagens === valor ? { backgroundColor: "#2f80c9" } : undefined}
                    >
                      {valor === "sim" ? "Sim" : "Não"}
                    </button>
                  ))}
                </div>
              </div>

              <div className="mt-5">
                <p className="mb-2.5 text-[10px] uppercase tracking-[0.2em] text-black/40">
                  Primeira viagem ao Japão?
                </p>
                <div className="flex gap-2.5">
                  {(["sim", "nao"] as const).map((valor) => (
                    <button
                      key={valor}
                      type="button"
                      onClick={() => setPrimeiraViagem(valor)}
                      className={`rounded-full border px-6 py-2 text-[11px] font-medium uppercase tracking-[0.1em] transition ${
                        primeiraViagem === valor
                          ? "border-transparent text-white"
                          : "border-black/20 text-black/60 hover:border-black/50 hover:text-black"
                      }`}
                      style={primeiraViagem === valor ? { backgroundColor: "#2f80c9" } : undefined}
                    >
                      {valor === "sim" ? "Sim" : "Não"}
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="button"
                onClick={handleQualificar}
                disabled={!qualProduto || !nome}
                className="mt-8 flex w-full items-center justify-center gap-2 rounded-full px-5 py-3.5 text-center text-[11px] font-semibold uppercase tracking-[0.2em] text-white shadow-[0_10px_30px_rgba(0,0,0,0.35)] transition duration-300 hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-40"
                style={{ backgroundColor: "#2f80c9" }}
              >
                Falar no WhatsApp →
              </button>
              {(!qualProduto || !nome) && (
                <p className="mt-2 text-center text-[11px] text-black/35">
                  Escolha um produto e informe seu nome para continuar.
                </p>
              )}
            </>
          )}
        </div>
      </section>

      {hoteisModalOpen && (
        <div
          className="fixed inset-0 z-[90] flex items-end justify-center bg-black/85 p-0 backdrop-blur-sm md:items-center md:p-6"
          role="dialog"
          aria-modal="true"
          aria-labelledby="hoteis-modal-title"
          onClick={() => setHoteisModalOpen(false)}
        >
          <div
            className="relative max-h-[92vh] w-full max-w-5xl overflow-y-auto rounded-t-3xl border border-black/10 bg-white shadow-2xl md:max-h-[88vh] md:rounded-3xl"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="sticky top-0 z-20 flex h-14 items-center justify-between border-b border-black/10 bg-white/90 px-4 backdrop-blur-xl md:px-6">
              <p
                id="hoteis-modal-title"
                className={`${display.className} text-lg font-medium text-black md:text-xl`}
              >
                Hotéis
              </p>
              <button
                type="button"
                onClick={() => setHoteisModalOpen(false)}
                aria-label="Fechar Hotéis"
                className="flex h-9 w-9 items-center justify-center rounded-full border border-black/15 text-2xl leading-none text-black/65 transition hover:border-black/40 hover:text-black"
              >
                ×
              </button>
            </div>
            <div className="p-5 md:p-8">
              <p className="max-w-2xl text-sm leading-relaxed text-black/60">
                Curadoria e reserva de hotéis escolhidos pelo perfil e pela logística da sua
                viagem — veja exemplos de propriedades por categoria.
              </p>
              {/* Pedido do Wilson, 16/set/2026: "melhorar a parte de hotéis
                  [...] quero algo similar a uma empresa que aluga hotéis
                  como SIXT, o cliente escolhe a categoria, e precisa
                  deixar opção pra escolher número de noites, datas e
                  cidades e tipo de quarto para poder gerar orçamento
                  inicial provisório" — inserido dentro do mesmo modal
                  "Hotéis" já existente, acima dos exemplos de propriedade
                  (que continuam disponíveis pra quem quiser só navegar). */}
              <div className="mt-6">
                <HotelQuoteCalculator />
              </div>
              <div className="mt-8 border-t border-black/10 pt-6">
                <HotelExemplosPropriedades light />
              </div>
            </div>
          </div>
        </div>
      )}

      {ajisaiShoppingModalOpen && (
        <ServicoAvulsoModal
          titulo="Ajisai Shopping"
          descricao="Acompanhamento pessoal em compras durante a viagem no Japão — negociação, tradução e apoio logístico nas lojas, do início ao fim da experiência de compra."
          precoLabel={`${(COMISSAO_AJISAI_SHOPPING_PCT * 100).toFixed(0)}% sobre as compras`}
          notaPreco="Comissão sobre o valor das compras realizadas com o acompanhamento — sem diária fixa. Valor final sob consulta, conforme o que for efetivamente gasto na viagem."
          cambio={cambio}
          onClose={() => setAjisaiShoppingModalOpen(false)}
        />
      )}

      <section aria-label="Por que escolher a Ajisai" className="border-t border-black/10 bg-white">
        <InstitutionalContent />
      </section>

      <footer className="bg-white px-8 pb-20 pt-16 text-black md:px-16 md:pb-20 md:pt-20">
        <div className="mx-auto flex max-w-2xl flex-col items-center gap-7 text-center">
          <img
            src="/images/AJISAI-LOGO.avif"
            alt="Ajisai"
            className="h-11 w-auto object-contain invert md:h-12"
          />
          <p className="max-w-sm text-sm leading-relaxed text-black/50">
            Pacotes de viagem e roteiros personalizados para o Japão.
          </p>
          <p className="text-[11px] leading-relaxed text-black/25">
            © 2026 AJISAIWORK JAPAN AGENCIA DE VIAGENS LTDA, Todos os Direitos
            Reservados — CNPJ: 43.544.605/0001-56
          </p>
        </div>
      </footer>
    </main>
  );
}

function InstitutionalContent() {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const observerRef = useRef<ResizeObserver | null>(null);
  const [height, setHeight] = useState(1800);

  useEffect(() => {
    return () => observerRef.current?.disconnect();
  }, []);

  function syncHeight() {
    const documentElement = iframeRef.current?.contentDocument?.documentElement;
    if (!documentElement) return;

    const updateHeight = () => {
      const iframeDocument = iframeRef.current?.contentDocument;
      if (!iframeDocument) return;
      setHeight(
        Math.max(
          iframeDocument.documentElement.scrollHeight,
          iframeDocument.body.scrollHeight,
        ),
      );
    };

    updateHeight();
    observerRef.current?.disconnect();
    observerRef.current = new ResizeObserver(updateHeight);
    observerRef.current.observe(documentElement);
  }

  return (
    <iframe
      ref={iframeRef}
      src="/pacotes?view=institutional"
      title="Por que escolher a Ajisai e avaliações de clientes"
      onLoad={syncHeight}
      scrolling="no"
      className="block w-full overflow-hidden border-0 bg-white"
      style={{ height }}
    />
  );
}

function ProductSelectorCard({
  href,
  onClick,
  icon,
  iconWidth,
  iconHeight,
  title,
  description,
  requirement,
  cta,
  featured = false,
  faixa = "verde",
  className = "",
}: {
  href: string;
  onClick?: () => void;
  icon: string;
  iconWidth: number;
  iconHeight: number;
  title: string;
  description: string;
  requirement?: string;
  cta: string;
  featured?: boolean;
  /** Faixa discreta no topo do card (Wilson, 26/out/2026 — mesmo padrão dos
   * indicadores do CRM): azul-escura nos produtos de viagem completa
   * (Roteiro Personalizado, Pacote de Viagem, Viagem Personalizada) e
   * verde-escura nos demais. */
  faixa?: "azul" | "verde";
  className?: string;
}) {
  return (
    <a
      href={href}
      style={{ borderTopColor: faixa === "azul" ? "#24476B" : "#28665D" }}
      onClick={(event) => {
        if (!onClick) return;
        event.preventDefault();
        onClick();
      }}
      className={`group relative flex h-[350px] flex-col overflow-hidden rounded-2xl border border-t-[3px] p-6 text-left transition md:p-8 ${
        featured
          ? "border-[#6ec3d9]/45 bg-[#6ec3d9]/[0.055] shadow-[0_0_34px_-12px_rgba(110,195,217,0.42)] hover:border-[#6ec3d9]/70 hover:bg-[#6ec3d9]/[0.075]"
          : "border-black/10 bg-black/[0.02] shadow-[0_18px_45px_-14px_rgba(37,99,235,0.55)] hover:border-black/25 hover:bg-black/[0.04] hover:shadow-[0_22px_55px_-12px_rgba(37,99,235,0.65)]"
      } ${className}`}
    >
      <Image
        src={icon}
        alt=""
        width={iconWidth}
        height={iconHeight}
        className={`absolute object-contain ${
          title === "Transporte Privado"
            ? "right-4 top-3 h-20 w-20 opacity-90 invert md:right-6 md:top-5"
            : // Pedido do Wilson, 16/set/2026: JR Pass/Câmbio/Seguro Viagem
              // reaproveitam os mesmos ícones já usados em
              // /servicos-adicionais — arte já escura, feita pra fundo
              // claro, então não precisa do invert/brightness-0 usado nos
              // ícones antigos de /images/produtos (esses sim, arte clara
              // pensada pra fundo escuro). Ajisai Shopping (ícone enviado
              // pelo Wilson, 16/set/2026) é a mesma convenção — arte escura
              // — e entrou aqui pelo mesmo motivo, corrigindo um bug onde
              // o ícone ficava invisível (invert numa arte já escura).
              title === "JR Pass" ||
              title === "Câmbio" ||
              title === "Seguro Viagem" ||
              title === "Ajisai Shopping" ||
              title === "eSIM"
              ? "right-6 top-5 h-14 w-14 opacity-80 md:right-8 md:top-7"
              : `right-6 top-5 h-14 w-14 md:right-8 md:top-7 ${
                  title === "Serviços adicionais" ? "brightness-0" : "opacity-90 invert"
                }`
        }`}
      />
      <div className="h-4" aria-hidden="true" />
      <h3 className={`${display.className} mt-3 pr-16 text-2xl font-medium text-black md:text-3xl`}>
        {title}
      </h3>
      <p className="mt-3 max-w-[34ch] flex-1 text-sm font-light leading-6 text-black/55">
        {description}
      </p>
      {requirement && (
        <span className="mt-4 w-fit rounded-full border border-red-400/40 bg-red-500/15 px-3 py-1.5 text-[9px] font-semibold uppercase tracking-[0.13em] text-red-700">
          {requirement}
        </span>
      )}
      <span className="mt-5 inline-flex w-fit items-center justify-center rounded-full bg-[#2f80c9] px-4 py-2.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-white shadow-[0_8px_24px_rgba(47,128,201,0.22)] transition group-hover:bg-[#3b91dc] group-hover:shadow-[0_10px_28px_rgba(47,128,201,0.35)]">
        {cta}
      </span>
    </a>
  );
}

// Tabela oficial do Japan Rail Pass, em ienes — só referência educativa
// nesta seção (o preço que a Ajisai efetivamente cobra é o de
// JR_PASS_PRECO_USD/JR_PASS_PRECO_USD_GREEN, tabela do fornecedor
// AjisaiWork em dólar, a mesma usada na Calculadora Reversa). Capturado
// em 25/set/2026 direto do site oficial japanrailpass.net: a tabela
// vigente até 30/set/2026 (adulto) é Comum ¥50.000/80.000/100.000 e
// Green ¥70.000/110.000/140.000 (7/14/21 dias); a partir de 1/out/2026
// (japanrailpass.net/assets/pdf/JRP_Price_Changes_En.pdf) sobe para os
// valores abaixo — como a mudança é em poucos dias, já uso a tabela nova
// pra não desatualizar rápido.
export const JR_PASS_OFICIAL_JPY: Record<"comum" | "green", Record<(typeof JR_PASS_DIAS_OPCOES)[number], number>> = {
  comum: { 7: 53000, 14: 84000, 21: 105000 },
  green: { 7: 74000, 14: 116000, 21: 147000 },
};

export function formatJPY(valor: number) {
  return `¥${valor.toLocaleString("ja-JP")}`;
}

// Pop-up dedicado do JR Pass — bem maior que o ServicoAvulsoModal genérico
// dos outros serviços avulsos, no mesmo padrão de tamanho do modal
// "Hotéis" (max-w-5xl, cabeçalho fixo com título + fechar, conteúdo
// rolável). Pedido do Wilson, 25/set/2026: "o pop-up está ocupando uma
// parte muito pequena, ele tem que ocupar praticamente o mesmo espaço da
// /produtos" + "tenham todos os detalhes desde os tipos de JR Pass
// disponiveis, dias, preços etc" + "Criteirios de eligibilidade" +
// "Usar sites oficiais da JR para capturar dados importantes". Critérios
// de elegibilidade e regras de uso abaixo vieram de japanrailpass.net/en
// (páginas "Eligibility for use" e "Conditions for use"), não inventados.
// Seção "Formas de pagamento" (cartão + Pix), reaproveitada nos dois
// self-checkouts de /produtos (JR Pass e Seguro Viagem). Pedido do Wilson,
// 25/set/2026: "adicionar formas de pagamento igual temos na pagina de
// calculadora reversa (adicionar dados de pagamento também na pagina de
// seguro viagem)". Mesmo visual/seleção da Calculadora Reversa
// (app/calculadora_reversa/page.tsx, seção "Simulação de pagamento") —
// não toquei nesse arquivo, só generalizei a mesma conta em
// app/lib/calculadoraCatalogoPublico.ts (calcularSimulacaoCartao/
// calcularSimulacaoPix/calcularParcelasMaxPix) pra reusar aqui.
export function FormasPagamento({
  totalBRL,
  dataViagem,
  formaPagamento,
  onEscolher,
  somenteAVista = false,
  metodos = ["cartao", "pix"],
  numeroPasso,
}: {
  totalBRL: number | null;
  /** Data de início da viagem (AAAA-MM-DD) — limita quantas parcelas de Pix fazem sentido. */
  dataViagem: string;
  formaPagamento: FormaPagamentoEscolhida | null;
  onEscolher: (forma: FormaPagamentoEscolhida) => void;
  /** Pedido do Wilson, 25/set/2026: "câmbio é sempre a vista" — desliga
   * parcelamento (cartão e Pix) só pra esse produto; JR Pass e Seguro
   * Viagem continuam com as opções normais (prop não passada = false). */
  somenteAVista?: boolean;
  /** Quais blocos aparecem — pedido do Wilson, 25/set/2026: "metodo de
   * pagamento é só pix e ted" (só pro Câmbio; os outros produtos continuam
   * com o padrão ["cartao", "pix"]). */
  metodos?: ("cartao" | "pix" | "ted")[];
  /** Numeração do passo (Wilson, 28/set/2026: "cada um dos passos até o
   * final deve ter uma numeração clara e evidente") — só o JR Pass passa
   * essa prop por enquanto; sem ela, o título aparece sem número (Câmbio,
   * Seguro Viagem, Transporte Privado). */
  numeroPasso?: number;
}) {
  if (totalBRL === null || totalBRL <= 0) return null;

  const mostrarCartao = metodos.includes("cartao");
  const mostrarPix = metodos.includes("pix");
  const mostrarTed = metodos.includes("ted");

  const simulacaoCartaoCompleta = calcularSimulacaoCartao(totalBRL);
  const simulacaoCartao = somenteAVista
    ? simulacaoCartaoCompleta.filter((op) => op.parcelas === 1)
    : simulacaoCartaoCompleta;
  const parcelasMaxPix = calcularParcelasMaxPix(dataViagem);
  const simulacaoPix = somenteAVista ? [] : calcularSimulacaoPix(totalBRL, parcelasMaxPix);

  return (
    <div className="mt-8 border-t border-black/10 pt-6">
      {numeroPasso !== undefined ? (
        <div className="flex items-center gap-2">
          <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[#2f80c9] text-[10px] font-semibold text-white">
            {numeroPasso}
          </span>
          <p className="text-[10px] uppercase tracking-[0.2em] text-black/40">Formas de pagamento</p>
        </div>
      ) : (
        <p className="text-[10px] uppercase tracking-[0.2em] text-black/40">Formas de pagamento</p>
      )}
      <p className="mt-1 text-[11px] leading-5 text-black/45">
        Simulação pra referência — valores sujeitos a confirmação no fechamento.
      </p>

      <div className="mt-4 flex flex-col gap-4">
        {/* Cartão de crédito */}
        {mostrarCartao && (
        <div className="rounded-xl border border-black/10 bg-black/[0.02] p-4 sm:p-5">
          <div className="flex items-center gap-3.5">
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#2f80c9]/10">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/images/icone-cartao-credito.png" alt="" className="h-7 w-7 object-contain" />
            </span>
            <div>
              <p className="text-sm font-medium text-black">Cartão de crédito</p>
              <p className="mt-0.5 text-[10px] text-black/50">
                {somenteAVista
                  ? `taxa de cartão ${(TAXA_MAQUINA_CARTAO * 100).toFixed(2).replace(".", ",")}% — à vista`
                  : `taxa de cartão ${(TAXA_MAQUINA_CARTAO * 100).toFixed(2).replace(".", ",")}% + juros de ${(TAXA_JUROS_CARTAO_MES * 100).toFixed(2).replace(".", ",")}% a.m. por parcela`}
              </p>
            </div>
          </div>
          <div className="mt-3 divide-y divide-black/[0.06] border-t border-black/[0.06]">
            {simulacaoCartao.map((op) => {
              const selecionado =
                formaPagamento?.metodo === "cartao" && formaPagamento.parcelas === op.parcelas;
              return (
                <label
                  key={op.parcelas}
                  className={`-mx-2 flex cursor-pointer items-center gap-3 rounded-lg px-2 py-2.5 transition ${
                    selecionado ? "bg-[#2f80c9]/[0.07]" : "hover:bg-black/[0.02]"
                  }`}
                >
                  <input
                    type="radio"
                    name="formaPagamento"
                    checked={selecionado}
                    onChange={() => onEscolher({ metodo: "cartao", parcelas: op.parcelas })}
                    className="h-4 w-4 shrink-0 accent-[#2f80c9]"
                  />
                  <span className="w-9 shrink-0 text-xs text-black/55">{op.parcelas}x</span>
                  <span className="flex-1 text-sm font-medium text-black">
                    {formatBRL(op.valorParcela)}
                  </span>
                  <span className="shrink-0 text-[11px] text-black/45">
                    total {formatBRL(op.valorTotal)}
                  </span>
                </label>
              );
            })}
          </div>
        </div>
        )}

        {/* Pix */}
        {mostrarPix && (
        <div className="rounded-xl border border-black/10 bg-black/[0.02] p-4 sm:p-5">
          <div className="flex items-center gap-3.5">
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#2f80c9]/10">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/images/icone-pix.png" alt="" className="h-7 w-7 object-contain" />
            </span>
            <div className="flex flex-wrap items-center gap-2">
              <p className="text-sm font-medium text-black">Pix</p>
              <span className="inline-flex items-center rounded-full bg-emerald-600/10 px-3.5 py-1.5 text-[18px] font-semibold uppercase tracking-[0.06em] text-emerald-700">
                Menor preço
              </span>
            </div>
          </div>

          <label
            className={`mt-3 flex cursor-pointer items-center gap-3 rounded-lg px-3.5 py-3 transition ${
              formaPagamento?.metodo === "pixVista"
                ? "bg-[#2f80c9]/[0.12]"
                : "bg-[#2f80c9]/5 hover:bg-[#2f80c9]/[0.08]"
            }`}
          >
            <input
              type="radio"
              name="formaPagamento"
              checked={formaPagamento?.metodo === "pixVista"}
              onChange={() => onEscolher({ metodo: "pixVista", parcelas: 1 })}
              className="h-4 w-4 shrink-0 accent-[#2f80c9]"
            />
            <span className="flex-1 text-xs text-black/60">à vista</span>
            <span className="text-sm font-medium text-black">{formatBRL(totalBRL)}</span>
          </label>

          {!somenteAVista &&
            (simulacaoPix.length > 0 ? (
              <div className="mt-3">
                <p className="text-[10px] text-black/50">
                  parcelado — entrada de {formatBRL(simulacaoPix[0].entrada)} (30%) + parcelas a{" "}
                  {(TAXA_JUROS_PIX_MES * 100).toFixed(2).replace(".", ",")}% a.m.
                </p>
                <div className="mt-1.5 divide-y divide-black/[0.06] border-t border-black/[0.06]">
                  {simulacaoPix.map((op) => {
                    const selecionado =
                      formaPagamento?.metodo === "pixParcelado" && formaPagamento.parcelas === op.parcelas;
                    return (
                      <label
                        key={op.parcelas}
                        className={`-mx-2 flex cursor-pointer items-center gap-3 rounded-lg px-2 py-2.5 transition ${
                          selecionado ? "bg-[#2f80c9]/[0.07]" : "hover:bg-black/[0.02]"
                        }`}
                      >
                        <input
                          type="radio"
                          name="formaPagamento"
                          checked={selecionado}
                          onChange={() => onEscolher({ metodo: "pixParcelado", parcelas: op.parcelas })}
                          className="h-4 w-4 shrink-0 accent-[#2f80c9]"
                        />
                        <span className="w-9 shrink-0 text-xs text-black/55">{op.parcelas}x</span>
                        <span className="flex-1 text-sm font-medium text-black">
                          {formatBRL(op.valorParcela)}
                        </span>
                        <span className="shrink-0 text-[11px] text-black/45">
                          total {formatBRL(op.valorTotal)}
                        </span>
                      </label>
                    );
                  })}
                </div>
              </div>
            ) : (
              dataViagem && (
                <p className="mt-3 text-[11px] text-black/45">
                  Viagem muito próxima — sem prazo pra parcelar no Pix, só à vista.
                </p>
              )
            ))}
        </div>
        )}

        {/* TED — pedido do Wilson, 25/set/2026: "metodo de pagamento é só
            pix e ted" (só aparece quando `metodos` inclui "ted"; hoje só
            o Câmbio passa isso). Sempre à vista — TED não parcela. */}
        {mostrarTed && (
        <div className="rounded-xl border border-black/10 bg-black/[0.02] p-4 sm:p-5">
          <div className="flex items-center gap-3.5">
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#2f80c9]/10">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/images/icone-pix.png" alt="" className="h-7 w-7 object-contain" />
            </span>
            <div>
              <p className="text-sm font-medium text-black">TED</p>
              <p className="mt-0.5 text-[10px] text-black/50">transferência bancária — à vista</p>
            </div>
          </div>
          <label
            className={`mt-3 flex cursor-pointer items-center gap-3 rounded-lg px-3.5 py-3 transition ${
              formaPagamento?.metodo === "ted"
                ? "bg-[#2f80c9]/[0.12]"
                : "bg-[#2f80c9]/5 hover:bg-[#2f80c9]/[0.08]"
            }`}
          >
            <input
              type="radio"
              name="formaPagamento"
              checked={formaPagamento?.metodo === "ted"}
              onChange={() => onEscolher({ metodo: "ted", parcelas: 1 })}
              className="h-4 w-4 shrink-0 accent-[#2f80c9]"
            />
            <span className="flex-1 text-xs text-black/60">à vista</span>
            <span className="text-sm font-medium text-black">{formatBRL(totalBRL)}</span>
          </label>
          <p className="mt-2 text-[10px] leading-4 text-black/40">
            Dados bancários da Alpinea enviados pela equipe no fechamento pelo WhatsApp.
          </p>
        </div>
        )}
      </div>
    </div>
  );
}

/** Texto curto descrevendo a forma de pagamento escolhida — usado na
 * mensagem de WhatsApp e no resumo do lead. Mesma lógica de
 * `descricaoFormaPagamentoEscolhida` da Calculadora Reversa. */
export function descricaoFormaPagamento(
  forma: FormaPagamentoEscolhida | null,
  totalBRL: number | null,
  dataViagem: string,
): string {
  if (!forma || totalBRL === null || totalBRL <= 0) return "";
  if (forma.metodo === "cartao") {
    const op = calcularSimulacaoCartao(totalBRL).find((o) => o.parcelas === forma.parcelas);
    if (!op) return "";
    return op.parcelas === 1
      ? `Cartão de crédito à vista (1x) de ${formatBRL(op.valorParcela)}`
      : `Cartão de crédito em ${op.parcelas}x de ${formatBRL(op.valorParcela)} (total ${formatBRL(op.valorTotal)})`;
  }
  if (forma.metodo === "pixVista") {
    return `Pix à vista de ${formatBRL(totalBRL)}`;
  }
  if (forma.metodo === "ted") {
    return `TED à vista de ${formatBRL(totalBRL)}`;
  }
  const parcelasMaxPix = calcularParcelasMaxPix(dataViagem);
  const op = calcularSimulacaoPix(totalBRL, parcelasMaxPix).find((o) => o.parcelas === forma.parcelas);
  if (!op) return "";
  return `Pix parcelado — entrada de ${formatBRL(op.entrada)} (30%) + ${op.parcelas}x de ${formatBRL(op.valorParcela)} (total ${formatBRL(op.valorTotal)})`;
}




/** Data de hoje em "AAAA-MM-DD" (hora local do navegador, não UTC) — usada
 * como `min` dos campos de data pra impedir selecionar dia no passado.
 * Pedido do Wilson, 28/set/2026: "desabilitar dias no passado" no
 * calendário de início/término da viagem (JR Pass, Seguro Viagem e
 * ida/volta de voo do Transporte Privado). */
export function hojeISO(): string {
  const agora = new Date();
  const ano = agora.getFullYear();
  const mes = String(agora.getMonth() + 1).padStart(2, "0");
  const dia = String(agora.getDate()).padStart(2, "0");
  return `${ano}-${mes}-${dia}`;
}

/** "AAAA-MM-DD" (input type=date) → "DD/MM/AAAA", pra mensagens de WhatsApp
 * e resumos legíveis. */
export function formatarDataBR(data: string): string {
  if (!data) return "";
  const [ano, mes, dia] = data.split("-");
  if (!ano || !mes || !dia) return data;
  return `${dia}/${mes}/${ano}`;
}



// Popup leve pra um serviço avulso simples (Ajisai Shopping) — mesmo
// padrão visual do popup de Hotéis, sem iframe, já que esses serviços não
// têm (e não precisam de) página própria. Pedido do Wilson, 16/set/2026:
// "JR Pass, Cambio e Seguro Viagem retirar do serviços avulsos, devem
// virar cards principais [...] seguir mesmo template de layout". JR
// Pass, Seguro Viagem e Câmbio saíram daqui em 25/set/2026 — ganharam
// componente próprio (JrPassModal, SeguroViagemModal, CambioModal),
// maiores e mais detalhados.
function ServicoAvulsoModal({
  titulo,
  descricao,
  precoLabel,
  precoBRLLabel,
  notaPreco,
  cambio,
  onClose,
}: {
  titulo: string;
  descricao: string;
  precoLabel: string;
  /** "ou R$ X" — null quando o preço já nasce em reais (não precisa de
   * uma segunda linha convertida). */
  precoBRLLabel?: string | null;
  notaPreco?: string;
  cambio: Cambio | null;
  onClose: () => void;
}) {
  return (
    <div
      className="fixed inset-0 z-[90] flex items-end justify-center bg-black/85 p-0 backdrop-blur-sm md:items-center md:p-6"
      role="dialog"
      aria-modal="true"
      aria-labelledby="servico-avulso-modal-title"
      onClick={onClose}
    >
      <div
        className="relative max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-t-3xl border border-black/10 bg-white p-6 shadow-2xl sm:rounded-3xl md:p-8"
        onClick={(event) => event.stopPropagation()}
      >
        <button
          type="button"
          onClick={onClose}
          aria-label={`Fechar ${titulo}`}
          className="absolute right-4 top-4 flex h-9 w-9 items-center justify-center rounded-full border border-black/15 text-2xl leading-none text-black/65 transition hover:border-black/40 hover:text-black"
        >
          ×
        </button>

        <p className="text-xs uppercase tracking-[0.3em] text-[#1c6ea8]">Serviço adicional</p>
        <h3
          id="servico-avulso-modal-title"
          className={`${display.className} mt-2 text-2xl font-medium text-black md:text-3xl`}
        >
          {titulo}
        </h3>
        <p className="mt-3 text-sm font-light leading-6 text-black/60">{descricao}</p>

        <div className="mt-6 border-t border-black/10 pt-6">
          <p className="text-[10px] uppercase tracking-[0.2em] text-black/40">A partir de</p>
          <p className={`${display.className} mt-1 text-3xl font-medium text-black`}>
            {precoLabel}
          </p>
          {precoBRLLabel && (
            <p className="mt-1 text-sm font-medium text-black/50">ou {precoBRLLabel}</p>
          )}
          {notaPreco && <p className="mt-1.5 text-[11px] text-black/40">{notaPreco}</p>}
          <CambioLabel cambio={cambio} className="mt-2 text-[11px] text-black/35" />
        </div>

        <ContactCTA
          mode="single"
          channel="whatsapp"
          whatsappNumber={WHATSAPP_NUMBER}
          brand="Ajisai"
          label={`Falar sobre ${titulo}`}
          buttonClassName="mt-7 block w-full rounded-full bg-[#2f80c9] px-6 py-4 text-center text-xs font-medium uppercase tracking-[0.25em] text-white transition hover:bg-[#3b91dc]"
          packageOptions={[titulo]}
          defaultPackage={titulo}
        />
      </div>
    </div>
  );
}

export function IconCheck({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.75"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <circle cx="12" cy="12" r="9" />
      <path d="M8.5 12.5l2.5 2.5 4.5-5" />
    </svg>
  );
}

// Vídeo real de demonstração — player nativo com poster, sem autoplay
// (carrega só metadata até o clique, pra não pesar a página).
function DemoVideo({
  src,
  poster,
  label,
  descricao,
}: {
  src: string;
  poster: string;
  label: string;
  descricao?: string;
}) {
  return (
    <div>
      <div className="relative aspect-video w-full overflow-hidden rounded-2xl border border-black/10 bg-black">
        <video
          controls
          preload="metadata"
          poster={poster}
          playsInline
          className="h-full w-full bg-black object-contain fullscreen:h-screen fullscreen:w-screen fullscreen:object-contain"
        >
          <source src={src} type="video/mp4" />
        </video>
      </div>
      <p className="mt-3 text-center text-[10px] uppercase tracking-[0.2em] text-[#1c6ea8]">
        {label}
      </p>
      {descricao && (
        <p className="mx-auto mt-1 max-w-xs text-center text-xs leading-5 text-black/50">
          {descricao}
        </p>
      )}
    </div>
  );
}
