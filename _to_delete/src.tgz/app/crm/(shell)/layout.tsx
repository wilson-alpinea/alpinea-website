import Link from "next/link";
import { NavCrm } from "./NavCrm";
import { MenuCrm } from "./MenuCrm";
import { headers } from "next/headers";
import { exigirAdmin } from "@/lib/crm/acesso";
import { INICIO_UNIDADE, NAV_CONSULTOR, UNIDADES_CRM, UNIDADE_COR, UNIDADE_CURTO, UNIDADE_LABEL, isUnidadeCrm, urlUnidade } from "@/lib/crm/unidades";
import { logout } from "../actions";

// Dois CRMs (Wilson, 21/out/2026): agência de viagens e empregos, cada um
// com o próprio menu. A unidade vem do proxy.ts (header x-crm-unidade).
const NAV_AGENCIA = [
  { href: "/crm", label: "Dashboard" },
  { href: "/crm/clientes", label: "Clientes" },
  { href: "/crm/fornecedores", label: "Fornecedores" },
  { href: "/crm/pipeline", label: "Pipeline" },
  { href: "/crm/acessos", label: "Acessos" },
];
const NAV_EMPREGOS = [
  { href: "/crm/empregos", label: "Candidatos" },
  { href: "/crm/empregos/agenda", label: "Agenda" },
  { href: "/crm/empregos/vagas", label: "Vagas" },
  { href: "/crm/acessos", label: "Acessos" },
];
// CRM de Seguro Viagem (Wilson, 26/out/2026).
// + Visão geral (Wilson, 29/out/2026), como a da Agência.
const NAV_SEGURO = [
  { href: "/crm/seguro/visao-geral", label: "Visão geral" },
  { href: "/crm/seguro", label: "Pedidos" },
  // eSIM dentro do Seguro — "CRM de Seguro Viagem & eSIM" (Wilson, 29/out/2026).
  { href: "/crm/seguro/esim", label: "eSIM" },
  { href: "/crm/acessos", label: "Acessos" },
];
// CRM de Documentação (Wilson, 29/out/2026).
const NAV_DOCUMENTACAO = [
  { href: "/crm/documentacao/visao-geral", label: "Visão geral" },
  { href: "/crm/documentacao", label: "Processos" },
  { href: "/crm/acessos", label: "Acessos" },
];
// CRM de Câmbio (Wilson, 29/out/2026).
const NAV_CAMBIO = [
  { href: "/crm/cambio", label: "Pedidos" },
  { href: "/crm/acessos", label: "Acessos" },
];
const NAV_UNIDADE = { agencia: NAV_AGENCIA, empregos: NAV_EMPREGOS, seguro: NAV_SEGURO, documentacao: NAV_DOCUMENTACAO, cambio: NAV_CAMBIO };

export default async function CrmShellLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // Só a equipe (admin) entra nas telas do CRM; parceiros têm portal próprio.
  const acesso = await exigirAdmin();
  const nomeExibicao = acesso.nome;
  const h = (await headers()).get("x-crm-unidade");
  const unidade = isUnidadeCrm(h) ? h : "agencia";
  // Consultor (migração 030): sem "Acessos" e só os CRMs liberados no menu.
  const consultor = acesso.papel === "consultor";
  const NAV = consultor ? [NAV_CONSULTOR[unidade]] : NAV_UNIDADE[unidade];
  const crmsVisiveis = consultor ? UNIDADES_CRM.filter((u) => acesso.permissoes?.crms.includes(u)) : UNIDADES_CRM;
  const rotuloUnidade = UNIDADE_LABEL[unidade];

  return (
    <div data-unidade={unidade} className="crm-pagina min-h-screen bg-[#FAF9F6] text-[#20252B]">
      <header className="sticky top-0 z-50 border-b border-white/10 bg-black backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-6 px-6 py-4 md:px-10">
          <div className="flex min-w-0 items-center gap-6 lg:gap-8">
            <Link href={consultor ? NAV_CONSULTOR[unidade].href : INICIO_UNIDADE[unidade]} className="flex items-center gap-4">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="/images/AJISAI-LOGO.avif"
                alt="Ajisai"
                className="h-8 w-auto sm:h-10"
              />
              <span className="hidden h-9 w-px bg-white/15 sm:block" />
              {/* Unidade embaixo de "CRM" para não invadir o menu (Wilson, 21/out/2026). */}
              <span className="hidden flex-col leading-none sm:flex">
                <span className="text-[28px] font-semibold leading-[1.1] text-white sm:text-[32px]">CRM</span>
                <span className="mt-1 text-[13px] text-white/45">{rotuloUnidade}</span>
              </span>
            </Link>
            <nav aria-label="Navegação do CRM" className="hidden items-center gap-5 whitespace-nowrap text-sm font-medium md:flex lg:gap-6">
              <NavCrm itens={NAV} variante="desktop" />
            </nav>
          </div>

          <div className="flex shrink-0 items-center gap-4">
            <span className="hidden text-[13px] text-white/35 xl:inline">
              {nomeExibicao}
              {acesso.cargo ? ` · ${acesso.cargo}` : ""}
            </span>
            <form action={logout}>
              <button
                type="submit"
                className="rounded-full border border-white/15 px-4 py-1.5 text-[13px] text-white/50 transition hover:border-white/40 hover:text-white"
              >
                Sair
              </button>
            </form>
            {/* Trocar de CRM: menu de três barras (Wilson, 29/out/2026), no
                lugar dos botões coloridos por unidade. */}
            <MenuCrm
              opcoes={crmsVisiveis.map((u) => ({
                chave: u,
                nome: UNIDADE_CURTO[u],
                href: urlUnidade(u),
                cor: UNIDADE_COR[u],
                atual: u === unidade,
              }))}
            />
          </div>
        </div>

        <nav aria-label="Navegação do CRM" className="flex items-center gap-5 overflow-x-auto border-t border-white/10 px-6 py-2.5 text-sm font-medium md:hidden">
          <NavCrm itens={NAV} variante="mobile" />
        </nav>
      </header>

      <main className="mx-auto max-w-6xl px-6 py-10 md:px-10 md:py-14">{children}</main>
    </div>
  );
}
