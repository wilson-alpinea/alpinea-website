import { NextResponse } from "next/server";
import { faturadoDisponivel, simpremiumConfigurado } from "../../../lib/simpremium/client";
import { buscarOfertasEsim } from "../../../lib/simpremium/ofertas";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// Catálogo público do eSIM para /produtos/esim — planos ilimitados do
// Japão da Simpremium com o preço final Ajisai. NUNCA devolve o NET
// (custo da agência) nem nada da conta da Ajisai na Simpremium.
export async function GET() {
  if (!simpremiumConfigurado()) {
    return NextResponse.json({ disponivel: false, planos: [], motivo: "nao_configurado" }, { status: 200 });
  }
  // `motivo` (Wilson, 29/out/2026: "o plano não está carregando"): diz POR
  // QUE a venda está desligada sem expor nada da conta — nao_configurado
  // (variáveis da Simpremium), faturado (crédito faturado não liberado),
  // sem_planos (nenhum ilimitado do Japão no catálogo) ou erro (API fora).
  try {
    // 29/out/2026 (Wilson: "plano segue sem poder selecionar no eSIM"): o
    // faturado da Simpremium não libera mais a vitrine. Os planos aparecem
    // sempre; sem faturado, a venda segue e o time emite o eSIM à mão
    // (aviso por e-mail na compra e o pedido fica "Erro — verificar" no CRM).
    const faturado = await faturadoDisponivel();
    if (!faturado.ok) console.error("[esim] faturado indisponível — emissão manual:", faturado.motivo);
    const ofertas = await buscarOfertasEsim();
    return NextResponse.json({
      disponivel: ofertas.planos.length > 0,
      ...(ofertas.planos.length === 0 ? { motivo: "sem_planos" } : {}),
      cotacao: ofertas.cotacao,
      planos: ofertas.planos.map((p) => ({
        id: p.id,
        nome: p.nome,
        faixas: p.faixas.map((f) => ({ minDays: f.minDays, maxDays: f.maxDays, precoUSD: f.precoUSD, precoBRL: f.precoBRL })),
      })),
    });
  } catch (erro) {
    console.error("Erro ao listar planos de eSIM na Simpremium:", erro);
    return NextResponse.json({ disponivel: false, planos: [], motivo: "erro" }, { status: 200 });
  }
}
