import { Bodoni_Moda } from "next/font/google";
import type { Metadata } from "next";
import {
  IconPlane,
  IconPlaneLanding,
  IconTrain,
  IconStar,
  IconDocument,
  IconRoute,
  IconMap,
  IconExchange,
} from "../components/AirportGuideKit";

const display = Bodoni_Moda({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
});

// Índice do banco de conteúdo interno — guias e atrações reutilizados na
// montagem de roteiros. Não faz parte do site público e não é indexado
// (ver robots.ts).
export const metadata: Metadata = {
  title: "Banco de Conteúdo Ajisai",
  description: "Conteúdo interno Ajisai — não indexado.",
  robots: {
    index: false,
    follow: false,
    nocache: true,
    googleBot: { index: false, follow: false },
  },
};

const categorias = [
  {
    href: "/database/aeroportos",
    titulo: "Guia de Aeroportos",
    resumo: "Chegada, imigração, deslocamento e recomendações — Narita, Haneda e Kansai.",
    Icon: IconPlane,
    disponivel: true,
  },
  {
    href: "/database/trem",
    titulo: "Metrô e Trens no Japão",
    resumo: "Tipos de trem, IC Card, transferências, etiqueta e as particularidades de Tokyo, Kyoto e Osaka.",
    Icon: IconTrain,
    disponivel: true,
  },
  {
    href: "/database/costumes",
    titulo: "Costumes & Etiqueta no Japão",
    resumo: "Filas, sapatos, restaurantes, templos, onsen, cumprimentos e o que observar no dia a dia da viagem.",
    Icon: IconStar,
    disponivel: true,
  },
  {
    href: "/database/palavras",
    titulo: "Palavras e Expressões Úteis",
    resumo: "Japonês de sobrevivência — as palavras e frases que realmente aparecem no dia a dia da viagem.",
    Icon: IconDocument,
    disponivel: true,
  },
  {
    href: "/database/shinkansen",
    titulo: "Shinkansen com JR Pass",
    resumo: "Qual trem usar, como reservar, embarcar e encontrar vagão e assento — Tokyo, Kyoto e Osaka.",
    Icon: IconRoute,
    disponivel: true,
  },
  {
    href: "/database/dxb",
    titulo: "Conexão em Dubai (DXB)",
    resumo: "GRU → DXB → NRT via Emirates — como seguir Connections, achar o portão e embarcar sem sair do aeroporto.",
    Icon: IconPlaneLanding,
    disponivel: true,
  },
  {
    href: "/database/onibus",
    titulo: "Ônibus em Kyoto",
    resumo: "Número da linha, direção e pontos A/B/C/D — como encontrar o ônibus certo mesmo quando o nome da parada se repete.",
    Icon: IconMap,
    disponivel: true,
  },
  {
    href: "/database/cambio",
    titulo: "Onde Trocar Dinheiro",
    resumo: "Casas de câmbio recomendadas em Tokyo (Ginza, Shinjuku) e Kyoto (Kyoto Station).",
    Icon: IconExchange,
    disponivel: true,
  },
];

export default function DatabaseIndexPage() {
  return (
    <main className="min-h-screen bg-black text-white">
      <header className="border-b border-white/10 bg-black px-6 py-5 md:px-10">
        <span className="text-xs uppercase tracking-[0.2em] text-white/40">
          Banco de Conteúdo Ajisai
        </span>
      </header>

      <section className="mx-auto max-w-5xl px-6 py-14 md:px-10 md:py-20">
        <p className="mb-4 text-xs uppercase tracking-[0.35em] text-white/40">Uso interno · não indexado</p>
        <h1 className={`${display.className} text-4xl font-medium leading-tight text-white md:text-6xl`}>
          Banco de Conteúdo
        </h1>
        <p className="mt-5 max-w-2xl text-base font-light leading-8 text-white/55">
          Guias e atrações que se repetem entre roteiros — usados como base ao montar
          o roteiro final de cada cliente. Este conteúdo não é destinado ao cliente
          diretamente e não deve ser linkado a partir de páginas públicas do site.
        </p>

        <div className="mt-14 grid gap-6 sm:grid-cols-2">
          {categorias.map((c) => (
            <a
              key={c.href}
              href={c.href}
              className="group rounded-2xl border border-white/10 bg-white/[0.025] p-6 transition hover:border-white/25 hover:bg-white/[0.04]"
            >
              <span className="flex h-10 w-10 items-center justify-center rounded-full bg-[#5b9bd5]/12 text-[#5b9bd5]">
                <c.Icon className="h-5 w-5" />
              </span>
              <h2 className={`${display.className} mt-5 text-xl font-medium text-white`}>{c.titulo}</h2>
              <p className="mt-3 text-sm leading-6 text-white/50">{c.resumo}</p>
              <p className="mt-5 text-xs uppercase tracking-[0.2em] text-white/30 transition group-hover:text-white/60">
                Ver guia →
              </p>
            </a>
          ))}
        </div>
      </section>
    </main>
  );
}
