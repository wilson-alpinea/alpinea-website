"use client";

// Layout de checkout: barra fixa enxuta (sem menu do site), resumo da vaga
// no topo e formulário abaixo, em coluna única. Wilson, 08/out/2026: "na
// candidatura o painel lateral deve sair da lateral" — o resumo deixou de
// ser coluna à direita no desktop e vale o mesmo layout do celular.

import Link from "next/link";
import { useRouter } from "next/navigation";
import { formatarDataPostagem, localVaga, type Vaga } from "../../../lib/vagasCatalogo";
import { useState } from "react";
import { CandidaturaModal, DetalhesVaga, InfoObrigatoriaVaga, display } from "../../EmpregosCliente";
import EsquemaTurno, { separarSalario } from "../../../components/empregos/EsquemaTurno";

// Resumo da vaga no topo do checkout — reorganizado em 08/out/2026 (Wilson:
// "parece tudo jogado, explicação de turno é difícil de entender"):
// cabeçalho com local e contrato, salário em destaque à esquerda e o
// esquema visual do turno à direita (EsquemaTurno).
function Resumo({ vaga }: { vaga: Vaga }) {
  const sal = separarSalario(vaga.salario);
  // "Ver detalhes da vaga" expande aqui mesmo, sem sair do checkout
  // (Wilson, 08/out/2026).
  const [aberto, setAberto] = useState(false);
  return (
    <div className="rounded-2xl border border-black/10 bg-[#f7f9fc]">
      <div className="flex items-start justify-between gap-4 p-5 md:px-7 md:pt-6">
        <div className="min-w-0">
          <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[#1f6fb8]">{vaga.empresa}</p>
          <p className={`${display.className} mt-1 text-xl font-medium leading-snug text-[#0A2540]`}>{vaga.titulo}</p>
          <div className="mt-2.5 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-black/60">
            <span className="flex items-center gap-1.5">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-3.5 w-3.5" aria-hidden="true">
                <path d="M12 21s-7-6.2-7-11.5A7 7 0 0 1 19 9.5C19 14.8 12 21 12 21z" />
                <circle cx="12" cy="9.5" r="2.5" />
              </svg>
              {localVaga(vaga)}
            </span>
            <span className="rounded-full bg-white px-2.5 py-0.5 ring-1 ring-black/10">{vaga.contrato}</span>
          </div>
        </div>
        {vaga.logo && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={vaga.logo} alt={vaga.empresa} className="h-7 max-w-[100px] shrink-0 object-contain" />
        )}
      </div>

      <div className="grid gap-px border-y border-black/10 bg-black/10 md:grid-cols-[minmax(0,0.8fr)_minmax(0,1.2fr)]">
        <div className="bg-white p-5 md:px-7">
          <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-black/45">Salário-base</p>
          <p className="mt-1 text-3xl font-semibold tabular-nums tracking-[-0.01em] text-[#0A2540]">{sal.principal}</p>
          {sal.detalhe && <p className="mt-2 text-xs leading-5 text-black/60">{sal.detalhe}</p>}
          <p className="mt-3 text-[11px] leading-5 text-black/40">Valor por hora, antes de horas extras e adicional noturno.</p>
        </div>
        <div className="bg-white p-5 md:px-7">
          <p className="mb-3 text-[10px] font-semibold uppercase tracking-[0.14em] text-black/45">Como funciona o turno</p>
          <EsquemaTurno turno={vaga.turno} />
        </div>
      </div>

      {aberto && (
        <div id="detalhes-vaga-checkout" className="space-y-8 border-b border-black/10 bg-white p-5 md:px-7 md:py-6">
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-black/45">Moradia, benefícios e cidade</p>
            <div className="mt-3">
              <InfoObrigatoriaVaga vaga={vaga} />
            </div>
          </div>
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-black/45">Outras condições</p>
            <div className="mt-3">
              <DetalhesVaga vaga={vaga} />
            </div>
          </div>
        </div>
      )}

      <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-2 px-5 py-3 md:px-7">
        <p className="text-[11px] text-black/45">
          Vaga <span className="font-mono font-semibold text-black/60">{vaga.codigo}</span> · Publicada em {formatarDataPostagem(vaga.publicadaEm)}
        </p>
        <button
          type="button"
          onClick={() => setAberto((v) => !v)}
          aria-expanded={aberto}
          aria-controls="detalhes-vaga-checkout"
          className="flex items-center gap-1 text-xs font-medium text-[#1f6fb8] underline decoration-[#1f6fb8]/30 underline-offset-2"
        >
          {aberto ? "Ocultar detalhes da vaga" : "Ver detalhes da vaga"}
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={`h-3.5 w-3.5 transition-transform ${aberto ? "rotate-180" : ""}`} aria-hidden="true">
            <path d="M6 9l6 6 6-6" />
          </svg>
        </button>
      </div>
    </div>
  );
}

export default function CheckoutCandidatura({ vaga, ativa }: { vaga: Vaga; ativa: boolean }) {
  const router = useRouter();
  const voltar = () => router.push(`/empregos/vagas/${vaga.id}`);

  return (
    <main className="min-h-screen bg-white pb-16 pt-14 text-black">
      <div className="fixed inset-x-0 top-0 z-50 flex h-14 items-center gap-3 bg-[#0A2540] px-4 md:px-8">
        <Link
          href={`/empregos/vagas/${vaga.id}`}
          className="flex min-h-[44px] items-center gap-1.5 text-xs font-medium uppercase tracking-[0.15em] text-white/70 transition hover:text-white"
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4" aria-hidden="true">
            <path d="M15 18l-6-6 6-6" />
          </svg>
          Vaga
        </Link>
        <span className="h-4 w-px bg-white/20" aria-hidden="true" />
        <p className={`${display.className} truncate text-base font-medium text-white sm:text-lg`}>Candidatura</p>
        <div className="flex-1" />
        <span className="hidden items-center gap-1.5 text-[11px] uppercase tracking-[0.14em] text-white/55 sm:flex">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-3.5 w-3.5" aria-hidden="true">
            <rect x="5" y="11" width="14" height="10" rx="2" />
            <path d="M8 11V7a4 4 0 0 1 8 0v4" />
          </svg>
          Dados protegidos
        </span>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/images/AJISAI-LOGO.avif" alt="Ajisai" className="h-6 w-auto object-contain md:h-7" />
      </div>

      <div className="mx-auto max-w-5xl px-4 pt-6 md:px-8 md:pt-10">
        <h1 className={`${display.className} text-2xl font-medium text-[#0A2540] md:text-3xl`}>Candidatura</h1>
        <p className="mt-1 text-sm text-black/55">Preencha seus dados e responda a triagem. Leva poucos minutos.</p>

        {!ativa ? (
          <div className="mt-6 rounded-2xl border border-amber-300 bg-amber-50 p-5 text-sm leading-6 text-amber-900">
            <p className="font-semibold">Esta vaga não está recebendo candidaturas no momento.</p>
            <p className="mt-1">
              Veja as vagas abertas no{" "}
              <Link href="/empregos#vagas" className="font-semibold underline underline-offset-2">
                catálogo da Ajisai
              </Link>
              .
            </p>
          </div>
        ) : (
          <div className="mt-6 grid gap-6">
            <Resumo vaga={vaga} />
            <CandidaturaModal vaga={vaga} onFechar={voltar} pagina />
          </div>
        )}

        <p className="mt-8 text-center text-[11px] text-black/40">
          Seus dados são usados só para esta candidatura, conforme a{" "}
          <Link href="/privacy" className="underline underline-offset-2">
            Política de Privacidade
          </Link>
          .
        </p>
      </div>
    </main>
  );
}
