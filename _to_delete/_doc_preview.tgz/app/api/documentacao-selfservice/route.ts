import { NextResponse } from "next/server";
import { atribuicaoDaRequisicao } from "../../../lib/crm/atribuicao";
import { createAdminClient } from "../../../lib/supabase/admin";
import { TAG_SELF_SERVICE } from "../../../lib/crm/origem";

export const runtime = "nodejs";

// Cadastro dos serviços de Documentação (/documentacao) — Wilson, 29/out/2026.
// Visto específico, Certificado de Elegibilidade e exportação de pet. Mesmo
// padrão de /api/passagens-selfservice: o lead cai no CRM da agência com a
// tag SELF-SERVICE e a equipe confirma o caso e o pagamento pelo WhatsApp
// (nada é cobrado no site). As respostas chegam como pares [pergunta,
// resposta] e vão inteiras para as observações do lead.

const NOMES: Record<string, string> = {
  visto: "Visto específico",
  elegibilidade: "Certificado de Elegibilidade",
  pet: "Exportação de pet",
};

function escapeHtml(value: unknown) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

const texto = (v: unknown, max = 500) => String(v ?? "").trim().slice(0, max);

async function notificarPorEmail(params: { assunto: string; email: string; resumoTexto: string; resumoHtml: string }) {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    console.error("RESEND_API_KEY não configurada — pulando notificação por e-mail (documentacao).");
    return;
  }
  try {
    const r = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: "Ajisai <contato@alpinea.io>",
        to: ["wilson@alpinea.io"],
        reply_to: params.email || undefined,
        subject: params.assunto,
        text: params.resumoTexto,
        html: params.resumoHtml,
      }),
    });
    if (!r.ok) console.error("Erro Resend (documentacao):", await r.text());
  } catch (err) {
    console.error("Erro ao notificar por e-mail (documentacao):", err);
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const servico = texto(body.servico, 30);
    const nomeServico = NOMES[servico];
    if (!nomeServico) return NextResponse.json({ error: "Serviço inválido." }, { status: 400 });

    const nome = texto(body.nome, 200);
    const email = texto(body.email, 200);
    const whatsapp = texto(body.whatsapp, 40);
    if (!nome || !email || !whatsapp) {
      return NextResponse.json({ error: "Nome, e-mail e WhatsApp são obrigatórios." }, { status: 400 });
    }

    const respostas: [string, string][] = Array.isArray(body.respostas)
      ? body.respostas
          .filter((r: unknown) => Array.isArray(r) && r.length === 2)
          .slice(0, 80)
          .map((r: unknown[]) => [texto(r[0], 200), texto(r[1], 1000)] as [string, string])
      : [];
    const vazias = respostas.filter(([, v]) => !v);
    if (respostas.length === 0 || vazias.length > 0) {
      return NextResponse.json({ error: "Responda todas as perguntas do cadastro." }, { status: 400 });
    }
    const valorReferenciaBRL = Number(body.valorReferenciaBRL) > 0 ? Math.round(Number(body.valorReferenciaBRL) * 100) / 100 : null;

    // Registro do aceite (até termos o contrato digital com assinatura):
    // data/hora do servidor, IP, navegador e versão dos termos.
    const aceites: string[] = Array.isArray(body.aceites) ? body.aceites.map((a: unknown) => texto(a, 200)).filter(Boolean).slice(0, 10) : [];
    const ip = (req.headers.get("x-forwarded-for") || "").split(",")[0].trim() || req.headers.get("x-real-ip") || "não identificado";
    const navegador = texto(req.headers.get("user-agent"), 300) || "não identificado";
    const registroAceite: [string, string][] = [
      ["Termos aceitos", aceites.length ? aceites.join(" | ") : "Nenhum"],
      ["Versão dos termos", texto(body.termosVersao, 80) || "não informada"],
      ["Aceite registrado em", new Date().toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo" }) + " (horário de Brasília)"],
      ["IP do aceite", ip],
      ["Navegador", navegador],
    ];
    respostas.push(...registroAceite);

    const titulo = `Novo cadastro — ${nomeServico} (Documentação)`;
    const resumoTexto = [titulo, "", `Nome: ${nome}`, `E-mail: ${email}`, `WhatsApp: ${whatsapp}`, "", ...respostas.map(([p, v]) => `${p}: ${v}`)].join("\n");
    const resumoHtml = `
      <div style="font-family: Arial, sans-serif; line-height: 1.6; color: #111;">
        <h2>${escapeHtml(titulo)}</h2>
        <p><strong>Nome:</strong> ${escapeHtml(nome)}<br/><strong>E-mail:</strong> ${escapeHtml(email)}<br/><strong>WhatsApp:</strong> ${escapeHtml(whatsapp)}</p>
        ${respostas.map(([p, v]) => `<p><strong>${escapeHtml(p)}:</strong> ${escapeHtml(v)}</p>`).join("\n")}
      </div>`.trim();

    const supabase = createAdminClient();
    const atribuicao = await atribuicaoDaRequisicao(req, supabase);
    const { data: cliente, error: erroCliente } = await supabase
      .from("clientes")
      .insert({
        ...atribuicao,
        nome,
        email,
        telefone: whatsapp,
        origem: `${TAG_SELF_SERVICE} — Documentação: ${nomeServico} (/documentacao)`,
        produto_principal: "servico_individual",
        produto_secundario: [],
        valor_proposta: valorReferenciaBRL,
        estagio: "novo_lead",
        observacoes: `[${TAG_SELF_SERVICE}]\n${resumoTexto}`,
      })
      .select("id")
      .single();

    if (erroCliente || !cliente) {
      console.error("Erro ao gravar lead (documentacao):", erroCliente);
      return NextResponse.json({ error: "Não foi possível registrar seu cadastro agora. Tente novamente ou fale pelo WhatsApp." }, { status: 500 });
    }

    const { error: erroInteracao } = await supabase.from("interacoes").insert({
      cliente_id: cliente.id,
      tipo: "simulacao",
      conteudo: `[${TAG_SELF_SERVICE}]\n${resumoTexto}`,
    });
    if (erroInteracao) console.error("Erro ao gravar interação (documentacao):", erroInteracao);

    await notificarPorEmail({ assunto: `[${TAG_SELF_SERVICE}] ${titulo} — ${nome}`, email, resumoTexto, resumoHtml });

    return NextResponse.json({ success: true, clienteId: cliente.id }, { status: 200 });
  } catch (error) {
    console.error("Erro no cadastro de Documentação:", error);
    return NextResponse.json({ error: "Erro interno do servidor. Fale com a Ajisai pelo WhatsApp." }, { status: 500 });
  }
}
